"""A2. Identified and inferred hindsight on the value target; sensitivity to unreported extensions
(round 1 revision, comments E3, R2.4, R3.2).

Run from the project root, after scripts 03 and 06:
    analysis/.venv/bin/python analysis/16_hindsight_tiers.py > analysis/16_hindsight_tiers_output.txt

Three tiers.
 (i)  Identified from the amendment history: the floor (script 06).
 (ii) Identified from notices not yet overwritten. For contracts of origins 2024 and 2025 that were
      amended and whose parent notice still shows its first-published fields, the seven-block value
      model is scored twice on the same contracts: with the duration as first published, and with the
      duration implied by the first amendment notice. The difference is the error reduction that
      revision of duration alone produces on the value target. (The amendment-target counterpart is
      Table 6, script 03, E2.)
 (iii) Inferred. The interval between floor and ceiling is the contribution of the contract-term block.
      The published upper bound of about 15% counts the share of that contribution arising on contracts
      later amended. If a share q of never-amended contracts had an extension that was never reported,
      part of the remainder is hindsight too. The upper bound is traced as a function of q for two
      cases: affected contracts chosen at random (expected value, and a 95% band over 200 draws), and
      the worst case, in which the affected contracts are those on which the term block reduces the
      squared error most. Per-contract reductions use the saved predictions of script 06.
 Anchor for q: the share of contracts whose every amendment notice carries an amendment value of zero
      (an amendment that changed no value). Such notices were common to 2021 and almost vanish after
      2023; a contract amended only by them would appear never amended if they went unreported.
Output: analysis/results/N2_tier2_value.csv, N2_sensitivity_q.csv, N2_q_anchor.csv, N2_tiers_summary.csv
"""
import numpy as np, pandas as pd
from lib import *

C = load_contracts()
PV = pd.read_pickle(CACHE + "preds_value.pkl")
rng = np.random.default_rng(SEED)

# ------------------------------------------------------------------ tier (iii): sensitivity curve over q
QS = [0, 0.01, 0.02, 0.03, 0.05, 0.075, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.0]
rows, base = [], []
for Y in FULL:
    q_ = PV[PV.origin == Y]; y = q_.y.values
    e8, e7, e6 = (y - q_.p_all8.values) ** 2, (y - q_.p_seven.values) ** 2, (y - q_.p_six.values) ** 2
    sst = np.sum((y - y.mean()) ** 2); den = sst - e8.sum()                 # SST * DI(all eight)
    amended = C.loc[q_.index, "ever_amended"].values == 1
    state = ~C.loc[q_.index, "fed"].values.astype(bool)                      # portals that record no amendments
    r = e6 - e7                                                               # per-contract reduction from the term block
    floor = (e7.sum() - e8.sum()) / den; term = r.sum() / den; ceiling = floor + term
    R_am, R_nv = r[amended].sum(), r[~amended].sum()
    base.append({"origin": Y, "floor": floor, "ceiling": ceiling, "term_part": term, "share_amended": R_am / r.sum(),
                 "upper_q0": floor + R_am / den, "n_never": int((~amended).sum()), "n_amended": int(amended.sum()),
                 # sensitivity: state and territory contracts count as never amended only because their portals record no
                 # amendments; if every one of their recorded durations were a revision, the bound at q = 0 would be:
                 "share_state": r[state].sum() / r.sum(), "upper_q0_state_revised": floor + (R_am + r[state].sum()) / den,
                 "n_state": int(state.sum())})
    rn = np.sort(r[~amended])[::-1]; cum = np.concatenate([[0], np.cumsum(rn)]); n_nv = len(rn)
    for q in QS:
        k = int(round(q * n_nv))
        draws = [rng.choice(r[~amended], k, replace=False).sum() if k else 0.0 for _ in range(200)]
        rows.append({"origin": Y, "q": q, "random_expected": floor + (R_am + q * R_nv) / den,
                     "random_lo": floor + (R_am + np.percentile(draws, 2.5)) / den,
                     "random_hi": floor + (R_am + np.percentile(draws, 97.5)) / den,
                     "worst_case_uncapped": floor + (R_am + cum[k]) / den,
                     "worst_case": min(ceiling, floor + (R_am + cum[k]) / den)})
B = pd.DataFrame(base); Q = pd.DataFrame(rows)
Qm = Q.groupby("q")[["random_expected", "random_lo", "random_hi", "worst_case", "worst_case_uncapped"]].mean().reset_index()
Qm["ceiling"] = B.ceiling.mean(); Qm["floor"] = B.floor.mean()
Q.to_csv(RES + "N2_sensitivity_q_by_origin.csv", index=False); Qm.to_csv(RES + "N2_sensitivity_q.csv", index=False)
print("Tier (iii). Upper bound of the hindsight share against q, mean over the nine fully observed origins")
print(B.round(4).to_string(index=False))
print("\n  floor %.1f%% | ceiling %.1f%% | share of the term-block reduction on later-amended contracts %.1f%% (per-origin mean)"
      % (100 * B.floor.mean(), 100 * B.ceiling.mean(), 100 * B.share_amended.mean()))
print("  upper bound at q = 0: %.1f%% (per-origin mean)" % (100 * B.upper_q0.mean()))
print("  state and territory contracts (no amendment recording): %.1f%% of evaluation contracts, %.1f%% of the term-block reduction;"
      " bound at q = 0 if all their durations were revisions: %.1f%% (%.1f%% to %.1f%%)"
      % (100 * (B.n_state / (B.n_never + B.n_amended)).mean(), 100 * B.share_state.mean(), 100 * B.upper_q0_state_revised.mean(),
         100 * B.upper_q0_state_revised.min(), 100 * B.upper_q0_state_revised.max()))
print(Qm.round(4).to_string(index=False))
print("  The worst case is capped at each origin's ceiling: summed over a selected subset, the per-contract reductions can exceed the\n"
      "  block's total, because the term block increases the error on some contracts; the uncapped values are kept in the file.")
k = np.argmax((Qm.worst_case >= Qm.ceiling - 1e-9).values)
print("  worst case reaches the ceiling (mean over origins) from about q = %.3f" % Qm.q[k])

# ------------------------------------------------------------------ anchor for q
N = pd.read_pickle(CACHE + "notices.pkl"); N = N[N.fed]
W = C[C.fed].copy()
A = N[(N.k > 0) & N.parent.isin(W.index)].copy(); A["zero"] = A.amendment_value == 0
g = A.groupby("parent").agg(n_zero=("zero", "sum"), n=("zero", "size"))
W = W.join(g); W["n_zero"] = W.n_zero.fillna(0); W["n"] = W.n.fillna(0)
W["only_zero"] = (W.n > 0) & (W.n_zero == W.n)
an = W.groupby("yr").agg(contracts=("value", "size"), never=("ever_amended", lambda s: (s == 0).mean()),
                         only_zero=("only_zero", "mean"))
an["q_anchor"] = an.only_zero / (an.never + an.only_zero)
zshare = A.groupby("yr").zero.mean().rename("zero_share_of_amendment_notices")
an = an.join(zshare); an.to_csv(RES + "N2_q_anchor.csv")
print("\nAnchor for q: Commonwealth contracts amended only by zero-value notices, by year of first publication")
print(an.round(4).to_string())
qa = an.loc[2015:2021, "q_anchor"]
print("  2015-2021: q anchor %.3f to %.3f (mean %.3f)" % (qa.min(), qa.max(), qa.mean()))
def at(q, col):
    return float(np.interp(q, Qm.q, Qm[col]))
lo_q, hi_q = qa.min(), qa.max()
print("  upper bound at the anchor range: random %.1f%% to %.1f%% | worst case %.1f%% to %.1f%%"
      % (100 * at(lo_q, "random_expected"), 100 * at(hi_q, "random_expected"), 100 * at(lo_q, "worst_case"), 100 * at(hi_q, "worst_case")))

# ------------------------------------------------------------------ tier (ii): value target, not-overwritten parents
T2, per = [], []
for Y in [2024, 2025]:
    tr = sample(C[C.yr.between(Y - 5, Y - 1)], SEED + Y); ev = C[C.yr == Y]
    ytr, yev = tr.ly.values, ev.ly.values
    Xtr, Xev, cols = encode(tr, ev, ytr, {})
    six, seven = use_cols(cols, SIX), use_cols(cols, SEVEN)
    import xgboost as xgb
    M7 = xgb.XGBRegressor(**HP).fit(Xtr[seven], ytr); M6 = xgb.XGBRegressor(**HP).fit(Xtr[six], ytr)
    p7, p6 = M7.predict(Xev[seven]), M6.predict(Xev[six])
    chk = np.abs(p7 - PV[PV.origin == Y].p_seven.reindex(ev.index).values).max()
    rev = (ev.a1_end - ev.contract_start).dt.days.values.astype(float)
    clean = (ev.ever_amended.values == 1) & (ev.overwritten.values == 0) & ~np.isnan(rev) & ev.duration.notna().values
    over = (ev.ever_amended.values == 1) & (ev.overwritten.values == 1)
    never = ev.ever_amended.values == 0
    Xr = Xev.copy(); Xr.loc[clean, "duration"] = rev[clean]
    p7r = M7.predict(Xr[seven])
    e6, e7, e7r = (yev - p6) ** 2, (yev - p7) ** 2, (yev - p7r) ** 2
    # current value: what the record shows once the parent is overwritten (value of the latest amendment notice)
    ycur = np.where(clean, np.log(ev.last_value.clip(lower=1.01).values), yev)
    c6, c7, c7r = (ycur - p6) ** 2, (ycur - p7) ** 2, (ycur - p7r) ** 2
    print("\nTier (ii), origin %d: max |p7 - script 06| = %.2e; amended, parent not overwritten: %d; overwritten: %d; never amended: %d"
          % (Y, chk, clean.sum(), over.sum(), never.sum()))
    per.append(pd.DataFrame({"origin": Y, "group": np.select([clean, over, never], ["clean", "over", "never"], "other"),
                             "red_fp": e6 - e7, "red_rev": e6 - e7r, "cur_fp": c6 - c7, "cur_rev": c6 - c7r, "dur_fp": ev.duration.values, "dur_rev": np.where(clean, rev, np.nan)}))
P = pd.concat(per)
def mean_ci(v, B=2000):
    v = np.asarray(v, float); bs = [rng.choice(v, len(v)).mean() for _ in range(B)]
    return v.mean(), np.percentile(bs, 2.5), np.percentile(bs, 97.5)
for nm, mask, col in [("Never amended; recorded duration", P.group == "never", "red_fp"),
                      ("Amended, parent not overwritten; duration as first published", P.group == "clean", "red_fp"),
                      ("Same contracts; duration after first amendment", P.group == "clean", "red_rev"),
                      ("Amended, parent overwritten; recorded duration", P.group == "over", "red_fp")]:
    m, lo, hi = mean_ci(P.loc[mask, col])
    T2.append({"evaluation set": nm, "n": int(mask.sum()), "mean_reduction": m, "lo": lo, "hi": hi})
c = P[P.group == "clean"]; m, lo, hi = mean_ci(c.red_rev - c.red_fp)
T2.append({"evaluation set": "Difference: revised minus first-published duration (same contracts)", "n": len(c), "mean_reduction": m, "lo": lo, "hi": hi})
for nm, col in [("Target current value; duration as first published", "cur_fp"), ("Target current value; duration after first amendment", "cur_rev")]:
    m, lo, hi = mean_ci(c[col]); T2.append({"evaluation set": "Same contracts. " + nm, "n": len(c), "mean_reduction": m, "lo": lo, "hi": hi})
m, lo, hi = mean_ci(c.cur_rev - c.cur_fp)
T2.append({"evaluation set": "Difference, target current value: revised minus first-published duration", "n": len(c), "mean_reduction": m, "lo": lo, "hi": hi})
T2 = pd.DataFrame(T2); T2.to_csv(RES + "N2_tier2_value.csv", index=False)
print("\nTier (ii). Mean reduction in squared error (log value) from the contract-term block, origins 2024-2025 pooled")
print(T2.round(4).to_string(index=False))
print("  median duration of the clean contracts: first published %.0f days, after first amendment %.0f days; share extended %.3f"
      % (np.nanmedian(c.dur_fp), np.nanmedian(c.dur_rev), np.mean(c.dur_rev > c.dur_fp)))

# ------------------------------------------------------------------ summary of the three tiers
E2 = pd.read_csv(RES + "E2_duration_first_published.csv")
S = pd.DataFrame([
    {"tier": "(i) identified: amendment history withheld (floor)", "value": B.floor.mean(), "lo": B.floor.min(), "hi": B.floor.max(), "assumption": "none beyond the record"},
    {"tier": "(ii) identified on the amendment target: AUC gain of first-published duration", "value": E2.gain.iloc[0], "lo": E2.lo.iloc[0], "hi": E2.hi.iloc[0], "assumption": "contracts whose parent escaped overwriting"},
    {"tier": "(ii) identified on the amendment target: AUC gain of the same contracts' revised duration", "value": E2.gain.iloc[1], "lo": E2.lo.iloc[1], "hi": E2.hi.iloc[1], "assumption": "as above"},
    {"tier": "(ii) identified on the value target (first-published value): extra error reduction from revised duration, per contract", "value": T2.mean_reduction.iloc[4], "lo": T2.lo.iloc[4], "hi": T2.hi.iloc[4], "assumption": "as above"},
    {"tier": "(ii) identified on the value target (current value): extra error reduction from revised duration, per contract", "value": T2.mean_reduction.iloc[-1], "lo": T2.lo.iloc[-1], "hi": T2.hi.iloc[-1], "assumption": "as above"},
    {"tier": "(iii) inferred: upper bound, q = 0", "value": B.upper_q0.mean(), "lo": B.upper_q0.min(), "hi": B.upper_q0.max(), "assumption": "never-amended contracts kept their first-published duration"},
    {"tier": "(iii) inferred: upper bound, q = 0, state and territory durations all revisions", "value": B.upper_q0_state_revised.mean(), "lo": B.upper_q0_state_revised.min(), "hi": B.upper_q0_state_revised.max(), "assumption": "Commonwealth never-amended contracts kept their first-published duration; every state and territory duration a revision"},
    {"tier": "(iii) inferred: upper bound at the anchor range of q, random", "value": at(hi_q, "random_expected"), "lo": at(lo_q, "random_expected"), "hi": at(hi_q, "random_expected"), "assumption": "q in the 2015-2021 anchor range, affected contracts at random"},
    {"tier": "(iii) inferred: upper bound at the anchor range of q, worst case", "value": at(hi_q, "worst_case"), "lo": at(lo_q, "worst_case"), "hi": at(hi_q, "worst_case"), "assumption": "q in the anchor range, affected contracts those the term block helps most"},
    {"tier": "ceiling: every recorded duration a revision", "value": B.ceiling.mean(), "lo": B.ceiling.min(), "hi": B.ceiling.max(), "assumption": "q = 1"},
])
S.to_csv(RES + "N2_tiers_summary.csv", index=False)
print("\nSummary of the three tiers"); print(S.round(4).to_string(index=False))
