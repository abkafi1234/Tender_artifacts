"""Write the LaTeX fragments for the supplementary analyses into analysis/supplement_tables/ (with script 22).

Run from the project root, after 02, 03 and 04:
    analysis/.venv/bin/python analysis/05_make_supp_tables.py
"""
import numpy as np, pandas as pd
OUT = "analysis/supplement_tables/"; import os; os.makedirs(OUT, exist_ok=True)
R = "analysis/results/"
pc = lambda x, d=1: f"{100*x:.{d}f}\\%"
com = lambda x: f"{int(x):,}".replace(",", "{,}")

def emit(name, caption, label, colspec, header, rows, note=None):
    L = [r"\begin{table}[H]", f"\\caption{{{caption}}}", f"\\label{{{label}}}", r"\small",
         r"\setlength{\tabcolsep}{3.4pt}", f"\\begin{{tabular}}{{{colspec}}}", r"\toprule",
         " & ".join(f"\\textbf{{{h}}}" for h in header) + r" \\", r"\midrule"]
    L += [r if isinstance(r, str) else " & ".join(r) + r" \\" for r in rows]
    L += [r"\bottomrule", r"\end{tabular}"]
    if note: L.append(r"\par\vspace{2pt}\noindent{\footnotesize " + note + r"\par}")
    L.append(r"\end{table}")
    open(OUT + name + ".tex", "w", encoding="utf-8").write("\n".join(L) + "\n"); print("wrote", name)

# 1. end-date change rate by year of the later notice
N = pd.read_pickle("analysis/cache/notices.pkl")
par = set(N[(N.k == 0) & N.fed].recid)
am = N[(N.k > 0) & N.parent.isin(par)].sort_values(["parent", "k"]).copy()
g = am.groupby("parent"); am["pk"] = g.k.shift(1); am["pe"] = g.contract_end.shift(1)
st = am[(am.k > 1) & (am.pk == am.k - 1) & am.contract_end.notna() & am.pe.notna()].copy()
st["chg"] = st.contract_end != st.pe
rows = []
for lab, m in [("2010 to 2014", st.yr.between(2010, 2014)), ("2015 to 2018", st.yr.between(2015, 2018)),
               ("2019 to 2022", st.yr.between(2019, 2022)), ("2023 to 2024", st.yr.between(2023, 2024)),
               ("2025, first to third quarter", (st.yr == 2025) & (st.published_date.dt.quarter < 4)),
               ("2025, fourth quarter", (st.yr == 2025) & (st.published_date.dt.quarter == 4))]:
    rows.append([lab, com(m.sum()), com(st[m].chg.sum()), pc(st[m].chg.mean())])
emit("tab_revyear",
     "End-date differences between consecutive amendment notices of one contract, by the year in which the later "
     "notice was published. The rate is zero for early notices and rises steeply for the most recent, which "
     "indicates that end dates on earlier notices have been overwritten with the current date.",
     "tab:revyear", "lrrr", ["Later notice published", "Steps", "End date differs", "Rate"], rows,
     note="Commonwealth contracts; consecutive amendment notices with an end date on both. Computed directly "
          "from the export.")

# 2. two by two
A, B = pd.read_csv(R + "A_contract_frame.csv"), pd.read_csv(R + "B_notice_frame.csv")
emit("tab_twobytwo",
     "Hindsight share by unit of analysis and by the timing assigned to recorded duration, mean over the fully "
     "observed origins. The classification of duration changes the share far more than the unit of analysis does.",
     "tab:twobytwo", "lrrr",
     ["Unit of analysis", "Duration at publication", "Duration post-award", "DI, six blocks"],
     [["Notice", pc(B.share_flag_only.mean()), pc(B.share_flag_and_term.mean()), f"{B.six.mean():.3f}"],
      ["Contract", pc(A.floor.mean()), pc(A.ceiling.mean()), f"{A.six.mean():.3f}"]],
     note="In the notice frame the post-award content is "
          "the amendment indicator of the export; in the contract frame it is the amendment history.")

# 3. duration as first published
# (tab_durfp, a one-panel copy of article Table 6, was removed in the round 1 revision: Table 6 with panels A and B is
#  written in the article itself, from E2_duration_first_published.csv and N3_equal_window.csv.)

# 4. (the table comparing the R and Python implementations was removed in the round 1 revision: Python is the only implementation)

# 5. term block by amendment status
F = pd.read_csv(R + "F_term_by_amendment_status.csv").groupby("group")[["n", "sse6", "sse7", "sst"]].sum()
red = F.loc["all"].sse6 - F.loc["all"].sse7
rows = []
for k, lab in [("never amended", "Never amended"), ("later amended", "Later amended"), ("all", "All contracts")]:
    r = F.loc[k]
    rows.append([lab, com(r.n), f"{1 - r.sse6 / r.sst:.3f}", f"{1 - r.sse7 / r.sst:.3f}",
                 f"{np.sqrt(r.sse6 / r.n):.3f}", f"{np.sqrt(r.sse7 / r.n):.3f}", pc((r.sse6 - r.sse7) / red)])
emit("tab_termstatus",
     "Contribution of the contract-term block to the value forecast, by whether the contract was later amended, pooled "
     "over the 2015 to 2023 origins. The last column is the share of the block's reduction in squared error.",
     "tab:termstatus", "lrrrrrr",
     ["Contracts", "$n$", "DI six", "DI seven", "Res.\\ SD six", "Res.\\ SD seven", "Share"], rows,
     note="Six: descriptive blocks. Seven: with the contract term. Never amended: contracts without a recorded amendment, "
          "including all state and territory contracts, whose portals publish no amendment notices.")

# 6. unseen suppliers
D = pd.read_csv(R + "D_unseen_supplier.csv")
emit("tab_unseen",
     "Value forecast from the seven at-publication blocks, by whether the supplier appears in the training sample, "
     "pooled over the 2015 to 2023 origins.",
     "tab:unseen", "lrrrr", ["Evaluation contracts", "$n$", "DI", "Total SD", "Residual SD"],
     [[r.group, com(r.n), f"{r.DI:.3f}", f"{r.total_sd:.3f}", f"{r.resid_sd:.3f}"] for r in D.itertuples()],
     note=None)

C = pd.read_csv(R + "C_first_published_target.csv")
print("first-published target: floor current %.1f%% (range %.1f-%.1f) | first-published %.1f%% (range %.1f-%.1f)" % (
    100*C.floor_current.mean(), 100*C.floor_current.min(), 100*C.floor_current.max(),
    100*C.floor_firstpub.mean(), 100*C.floor_firstpub.min(), 100*C.floor_firstpub.max()))
print("term share on amended: %.3f | narrowed ceiling: %.1f%% | with manuscript floor and ceiling: %.1f%%" % (
    (F.loc['later amended'].sse6-F.loc['later amended'].sse7)/red,
    100*(A.floor.mean()+ (A.ceiling.mean()-A.floor.mean())*(F.loc['later amended'].sse6-F.loc['later amended'].sse7)/red),
    4.4+(30.0-4.4)*(F.loc['later amended'].sse6-F.loc['later amended'].sse7)/red))

# 7. absolute error with placeholder values retained (script 14)
T = pd.read_csv(R + "R3_robust_trend.csv").set_index(["variant", "measure"])
pv = lambda p: "$<0.001$" if p < 0.001 else f"{p:.3f}"
rows = []
for m, lab in [("di", "DI"), ("skill_abs", "Absolute-error skill"), ("rsd", "Residual SD"), ("mae", "Mean absolute error"),
               ("medae", "Median absolute error"), ("mad", "Mean absolute deviation of target")]:
    e, r = T.loc[("excluded", m)], T.loc[("retained", m)]
    rows.append([lab, f"{e['first']:.3f}", f"{e['last']:.3f}", pv(e.mk_p), f"{r['first']:.3f}", f"{r['last']:.3f}", pv(r.mk_p)])
emit("tab_robusttrend",
     "Value forecast from all eight blocks at the 2015 and 2025 origins, with the Mann--Kendall $p$-value over the eleven "
     "origins, when the 431 placeholder values are excluded and when they are retained.",
     "tab:robusttrend", "lrrrrrr",
     ["Measure", "2015", "2025", "$p$", "2015", "2025", "$p$"],
     [r"& \multicolumn{3}{c}{\textbf{Excluded}} & \multicolumn{3}{c}{\textbf{Retained}} \\"] + rows,
     note="Absolute-error skill: one minus the ratio of the sum of absolute errors to the sum of absolute deviations from the "
          "evaluation-set median.")

J = pd.read_csv(R + "R3_robust_jurisdiction.csv"); J = J[(J.pool == "last three origins") & (J.variant != "retained_l1")]
emit("tab_robustjuris",
     "Jurisdiction comparison on the seven at-publication blocks, origins 2023 to 2025 pooled, when the placeholder values "
     "are excluded and when they are retained.",
     "tab:robustjuris", "llrrrrrrr",
     ["Placeholders", "Group", "$n$", "DI", "Skill", "Res.\\ SD", "MAE", "MedAE", "MAD"],
     [[{"excluded": "Excluded", "retained": "Retained"}[r.variant], r.group, com(r.n), f"{r.di:.3f}", f"{r.skill_abs:.3f}",
       f"{r.rsd:.3f}", f"{r.mae:.3f}", f"{r.medae:.3f}", f"{r.mad:.3f}"] for r in J.sort_values(["variant", "group"]).itertuples()],
     note="Skill: absolute-error skill. MAE and MedAE: mean and median absolute error. MAD: mean absolute deviation of the "
          "target from its median.")

# 8. Shapley partition with capacity matched to coalition size (script 07)
S = pd.read_csv(R + "S9_shapley_size_matched.csv").sort_values("rank_d6")
emit("tab_sizematched",
     "Shapley shares of DI on the value target at the 2023 origin, with one model capacity for all coalitions and with tree "
     "depth matched to the number of blocks in each coalition.",
     "tab:sizematched", "lrrrr", ["Block", "Share, depth 6", "Rank", "Share, matched depth", "Rank"],
     [[r.name, pc(r.share_d6), str(r.rank_d6), pc(r.share_matched), str(r.rank_matched)] for r in S.itertuples(index=False)],
     note="Share, depth 6: one capacity for all coalitions, as in Table~\\ref{tab:shapley_value}. Matched depth: 3 for "
          "coalitions of one or two blocks, 4 for three to five, 6 for six to eight.")
