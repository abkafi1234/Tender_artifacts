"""Check the numbers written in the text of the article against the result tables.

Run from the project root, after scripts 01 to 22:
    analysis/.venv/bin/python analysis/23_check_manuscript_numbers.py <path to manuscript.tex>
Every check recomputes a quantity from analysis/results/, formats it as the article prints it, and
confirms that this exact string occurs in the article. The tables of the supplement need no check,
because script 22 writes them from the same results. Output: a PASS/FAIL line per check; exit code 1
if any check fails.
"""
import re, sys
import numpy as np, pandas as pd

TEX = open(sys.argv[1], encoding="utf-8").read()
TXT = re.sub(r"\s+", " ", TEX)
R = "analysis/results/"
rd = lambda f, **k: pd.read_csv(R + f, **k)
M1, M2, M3 = rd("M1_di_by_origin.csv"), rd("M2_trend_tests.csv").set_index("series"), rd("M3_hindsight.csv")
F = M3[M3.origin <= 2023]
D1 = rd("D1_sample.csv").set_index("step").records
G1, G3 = rd("G1_contrasts.csv"), rd("G3_jurisdiction.csv")
T1, T2, T4 = rd("T1_amendment_by_origin.csv"), rd("T2_duration_test.csv"), rd("T4_strata.csv").set_index("stratum")
T3, E2 = rd("T3_no_gap.csv"), rd("E2_duration_first_published.csv")
S2, S8 = rd("S2_shapley_value.csv").set_index("block"), rd("S8_cross_target.csv")
N1, N1T, N1J = rd("N1_reference_by_origin.csv"), rd("N1_reference_trend.csv"), rd("N1_reference_jurisdiction.csv").set_index("group")
N2t, N2v, QA, SQ = rd("N2_tiers_summary.csv"), rd("N2_tier2_value.csv"), rd("N2_q_anchor.csv", index_col=0), rd("N2_sensitivity_q.csv")
N3 = rd("N3_equal_window.csv")
N4v, N4a, N4d = rd("N4_value_summary.csv").set_index("model"), rd("N4_amend_by_origin.csv"), rd("N4_duration_test.csv")
N5, N5n = rd("N5_seeds_summary.csv"), rd("N5_no_subsample.csv")
B, G9 = rd("B_notice_frame.csv"), rd("G9_compliance_agencies.csv").set_index("association")
R2 = rd("R2_placeholders.csv"); RJ = rd("R3_robust_jurisdiction.csv")
from scipy import stats

f3 = lambda x: f"{x:.3f}"; p1 = lambda x: f"{100*x:.1f}\\%"; com = lambda x: f"{int(x):,}".replace(",", "{,}")
checks = []
def chk(label, s):
    ok = re.sub(r"\s+", " ", s) in TXT
    checks.append(ok); print("PASS" if ok else "FAIL", "|", label, "|", s)

# --- sample
chk("contracts analysed", com(D1["Contracts analysed"]))
chk("notices with a value", com(D1["Contract notices published 2010-2025 with a recorded value"]))
chk("contracts before exclusions", com(D1["Contracts (one row per parent notice)"]))
chk("values <= 0", com(D1["recorded value of zero or less (no logarithm)"]))
chk("Commonwealth share", f"{100*D1['of which Commonwealth']/D1['Contracts analysed']:.1f}\\%")
# --- trend
chk("DI 2015", f3(M1.all8.iloc[0])); chk("DI 2022 peak", f3(M1.all8.max())); chk("DI 2025", f3(M1.all8.iloc[-1]))
chk("trend p", "$p = %.3f$" % M2.loc["DI, all eight blocks", "mk_p"])
chk("total SD p", "$p = %.4f$" % M2.loc["Total SD of target", "mk_p"])
chk("resid SD p", "$p = %.3f$" % M2.loc["Residual SD, all eight blocks", "mk_p"])
chk("resid SD range", "between $%.2f$ and $%.2f$" % (M1.all8_rsd.min(), M1.all8_rsd.max()))
last = M2.loc["DI all eight: last three origins minus first three"]
chk("last3-first3", "$+%.3f$ (95\\%% CI $+%.3f$ to $+%.3f$, $p = %.3f$)" % (last.tau, last.ci_lo, last.ci_hi, last.mk_p))
chk("balanced panel p", "($p = %.3f$)" % M2.loc["DI, balanced agency panel", "mk_p"])
# --- hindsight
chk("floor mean", "4.5\\%"); assert abs(F.floor.mean() - 0.045) < 0.0005
chk("abstract: mean DI, fully observed origins", "DI averages %.2f, of which" % M1[M1.origin <= 2023].all8.mean())
chk("floor range", "(range %s to %s)" % (p1(F.floor.min()), p1(F.floor.max())))
chk("ceiling", "averages %s (%s to %s)" % (p1(F.ceiling.mean()), p1(F.ceiling.min()), p1(F.ceiling.max())))
chk("floor significant at 8 of 9", "eight of the nine"); assert (F.floor_holm < 0.05).sum() == 8
chk("tier ii value", "$%.3f$ per contract (95\\%% CI $%.3f$ to $%.3f$)" % (N2v.mean_reduction.iloc[-1], N2v.lo.iloc[-1], N2v.hi.iloc[-1]))
chk("tier ii n", com(N2v.n.iloc[1]))
up0 = N2t.set_index("tier").loc["(iii) inferred: upper bound, q = 0"]
chk("upper q0", "at most %s (mean over origins; range %s to %s)" % (p1(up0.value), p1(up0.lo), p1(up0.hi)))
qa = QA.loc[2015:2021, "q_anchor"]
chk("q anchor range", "%s to %s of the contracts that would appear never amended" % (p1(qa.min()), p1(qa.max())))
FT = rd("F_term_by_amendment_status.csv"); FT["red"] = FT.sse6 - FT.sse7
chk("never-amended share of term reduction", "account for %d\\%% of the reduction" % round(100 * FT[FT.group == "never amended"].red.sum() / FT[FT.group == "all"].red.sum()))
st = N2t.set_index("tier").loc["(iii) inferred: upper bound, q = 0, state and territory durations all revisions"]
chk("bound, state durations revised", "the bound would be %s (Supplementary Table~S34)" % p1(st.value))
rnd = N2t.set_index("tier").loc["(iii) inferred: upper bound at the anchor range of q, random"]
wst = N2t.set_index("tier").loc["(iii) inferred: upper bound at the anchor range of q, worst case"]
chk("anchor random", "%s to %s under random selection" % (p1(rnd.lo), p1(rnd.hi)))
chk("anchor worst", "%s to %s in the worst case" % (p1(wst.lo), p1(wst.hi)))
zs = QA["zero_share_of_amendment_notices"]
chk("zero-value notices 2024 and 2025", "fell to %s in 2024\nand almost disappeared in 2025 (%s)" % (p1(zs.loc[2024]), p1(zs.loc[2025])))
chk("random at q=10%", p1(SQ.set_index("q").loc[0.10, "random_expected"]) + " at $q = 10\\%$")
# --- frames
chk("notice frame six", "$%.3f$ over the fully observed origins, compared with $%.3f$" % (B.six.mean(), F.six.mean()))
chk("in-train range", "%d\\%% to %d\\%% of evaluation notices" % (round(100*B.in_train.min()), round(100*B.in_train.max())))
# --- Shapley
chk("term share", p1(S2.loc["term", "share"])); chk("text share", p1(S2.loc["text", "share"]))
chk("hist share", p1(S2.loc["hist", "share"])); chk("full DI", "$%.3f$" % S2.shapley.sum())
chk("Spearman 7", "$%.3f$" % stats.spearmanr(S8.rank_value, S8.rank_amend).correlation)
chk("agency share, seven-block partition", "(%s of DI in the seven-block partition)" % p1(S8.set_index("block").loc["agency", "share_value"]))
s6 = S8[S8.block != "term"]; chk("Spearman 6", "$%.3f$" % stats.spearmanr(s6.share_value, s6.share_amend).correlation)
# --- jurisdictions
c = G1.iloc[0]; g = G3[G3.spec == "Full field set"].set_index("group")
chk("juris DI", "$%.3f$ for the Commonwealth against $%.3f$" % (g.loc["Commonwealth", "DI"], g.loc["State and territory", "DI"]))
chk("juris diff", "$+%.3f$ (95\\%% CI $%.3f$ to $%.3f$, Holm $p = %.3f$)" % (c["diff"], c.lo, c.hi, c.holm_p))
chk("juris RSD", "$%.3f$ and $%.3f$" % (g.loc["Commonwealth", "resid_sd"], g.loc["State and territory", "resid_sd"]))
chk("common core shrink", "%.1f\\%%" % (100 * (1 - G1.iloc[1]["diff"] / c["diff"])))
d = N1J.loc["difference (train_pooled)"]
chk("pooled reversal", "($%.3f$, 95\\%% CI $%.3f$ to $%.3f$)" % (d.DI_train_pooled, d.lo, d.hi))
chk("compliance raw", "$+%.3f$ ($p = %.3f$)" % (G9.loc["Compliance and DI (raw)", "estimate"], G9.loc["Compliance and DI (raw)", "p"]))
chk("compliance adj", "($+%.3f$, $p = %.3f$)" % (G9.loc["Compliance and adjusted DI (primary)", "estimate"], G9.loc["Compliance and adjusted DI (primary)", "p"]))
# --- amendment
chk("AUC six", "$%.3f$ over the seven origins" % T2.auc_six.mean())
chk("AUC +dur", "increases the mean AUC to $%.3f$" % T2.auc_six_duration.mean())
chk("AUC seven range", "between $%.3f$ and $%.3f$ (mean $%.3f$)" % (T1.auc.min(), T1.auc.max(), T1.auc.mean()))
chk("open/limited AUC", "($%.3f$ and $%.3f$)" % (T4.loc["open", "auc"], T4.loc["limited", "auc"]))
chk("no-gap gain", "by $%.3f$ to $%.3f$ (mean $%.3f$)" % (T3.difference.min(), T3.difference.max(), T3.difference.mean()))
for i, r in E2.iterrows():
    chk("Table 6A row %d" % (i + 1), "%.3f & %.3f & \\textbf{%+.3f} & [%+.3f, %+.3f]" % (r.auc_six, r.auc_six_duration, r.gain, r.lo, r.hi))
for i, r in N3.iterrows():
    chk("Table 6B row %d" % (i + 1), "%.3f & %.3f & \\textbf{%+.3f} & [%+.3f, %+.3f]" % (r.auc_six, r.auc_six_duration, r.gain, r.lo, r.hi))
# --- robustness
chk("sentinel max", "$%.3f$" % M1.sentinel.max()); chk("sentinel min", "$%.3f$" % M1.sentinel.min())
chk("placeholder trend p", "$p = %.3f$ rather than" % stats.kendalltau(R2.origin, R2.all8)[1])
pr = R2[R2.origin <= 2023]
chk("placeholder floor/ceiling", "(floor %s, ceiling %s)" % (p1(pr.floor.mean()), p1(pr.ceiling.mean())))
chk("training-mean DI", "$%.3f$ rather than $%.3f$" % (N1.all8_train.mean(), N1.all8_ev.mean()))
tr = N1T[(N1T.reference == "train") & (N1T.series == "all8")].mk_p.iloc[0]; chk("training-mean trend", "($p = %.3f$)" % tr)
chk("ridge DI", "$%.3f$ with all eight blocks" % N4v.loc["Ridge, eight blocks", "mean_DI"])
chk("lookup DI", "$%.3f$" % N4v.loc["Group-mean lookup", "mean_DI"])
chk("ridge floor", p1(N4v.loc["Ridge: floor (mean over 2015-2023)", "mean_DI"]))
chk("logit AUC", "$%.3f$ with the six descriptive blocks and $%.3f$ with duration" % (N4a.logit_auc_six.mean(), N4a.logit_auc_six_duration.mean()))
chk("logit duration test", "($%+.3f$, $%+.3f$, $%+.3f$" % tuple(N4d.gain.values))
chk("seed DI range", "between $%.3f$ and $%.3f$" % (N5.mean_all8.min(), N5.mean_all8.max()))
chk("seed floor range", "between %s and %s" % (p1(N5.floor_mean.min()), p1(N5.floor_mean.max())))
chk("no-subsample n", "%s to %s contracts" % (com(N5n.n_train.min()), com(N5n.n_train.max())))

print("\n%d of %d checks passed" % (sum(checks), len(checks)))
sys.exit(0 if all(checks) else 1)
