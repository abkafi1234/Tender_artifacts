"""Figures for the analyses added in the round 1 revision (scripts 15 to 19). Written to analysis/figures/.

Run from the project root, after scripts 15 to 19:
    analysis/.venv/bin/python analysis/21_revision_figures.py
Same style as 12_figures.py.
R11_hindsight_sensitivity: upper bound of the hindsight share against q (script 16, N2_sensitivity_q.csv).
R12_reference_forecast:    DI of the eight-block forecast under three reference forecasts (script 15).
"""
import os
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from lib import RES

OUT = "analysis/figures/"; os.makedirs(OUT, exist_ok=True)
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, MUTED, GRID, BAND = "#0b0b0b", "#898781", "#e6e5e1", "#f0efec"
plt.rcParams.update({"font.size": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
                     "axes.axisbelow": True, "lines.linewidth": 2, "lines.markersize": 5, "legend.frameon": False,
                     "figure.dpi": 200, "savefig.bbox": "tight", "pdf.fonttype": 42, "axes.titlesize": 9.5, "axes.titleweight": "bold", "axes.titlelocation": "left"})


def save(fig, name):
    fig.savefig(OUT + name + ".pdf"); fig.savefig(OUT + name + ".png"); plt.close(fig); print("wrote", name)


# ---- R11: sensitivity of the upper bound to unreported extensions ------------------------------
Q = pd.read_csv(RES + "N2_sensitivity_q.csv")
A = pd.read_csv(RES + "N2_q_anchor.csv", index_col=0).loc[2015:2021, "q_anchor"]
x = 100 * Q.q
fig, ax = plt.subplots(figsize=(6.0, 3.3))
ax.axvspan(100 * A.min(), 100 * A.max(), color=BAND, zorder=0)
ax.text(100 * A.max() + 1.2, 6.2, "q suggested by\nzero-value amendments,\n2015\u20132021", color=MUTED, fontsize=7.5, va="bottom")
ax.axhline(100 * Q.ceiling.iloc[0], color=INK, linewidth=1, linestyle="--")
ax.axhline(100 * Q.floor.iloc[0], color=INK, linewidth=1, linestyle=":")
ax.fill_between(x, 100 * Q.random_lo, 100 * Q.random_hi, color=BLUE, alpha=0.25, linewidth=0)
ax.plot(x, 100 * Q.random_expected, color=BLUE, label="Affected contracts at random")
ax.plot(x, 100 * Q.worst_case, color=ORANGE, label="Worst case (capped at the ceiling)")
ax.text(101, 100 * Q.ceiling.iloc[0], "ceiling %.1f%%" % (100 * Q.ceiling.iloc[0]), va="center", fontsize=7.5, color=INK)
ax.text(101, 100 * Q.floor.iloc[0], "floor %.1f%%" % (100 * Q.floor.iloc[0]), va="center", fontsize=7.5, color=INK)
ax.annotate("%.1f%% at q = 0" % (100 * Q.random_expected.iloc[0]), xy=(0, 100 * Q.random_expected.iloc[0]), xytext=(24, 12.6),
            fontsize=7.5, color=INK, arrowprops=dict(arrowstyle="-", color=MUTED, linewidth=0.8))
ax.set_xlim(-1, 100); ax.set_ylim(0, 36)
ax.set_xlabel("q: share of never-amended contracts with an unreported extension (%)")
ax.set_ylabel("Upper bound of hindsight share, % of DI")
ax.set_title("Upper bound of the hindsight share against unreported extensions")
ax.legend(loc="center right")
save(fig, "R11_hindsight_sensitivity")

# ---- R12: DI under three reference forecasts -----------------------------------------------------
R = pd.read_csv(RES + "N1_reference_by_origin.csv")
fig, ax = plt.subplots(figsize=(6.0, 3.0))
ax.axvspan(2023.5, 2025.5, color=BAND, zorder=0)
for col, c, lab in [("all8_ev", BLUE, "Evaluation-set mean (Eq. 1)"), ("all8_train", AQUA, "Training-window mean"),
                    ("all8_train_cat", ORANGE, "Training mean by product category")]:
    ax.plot(R.origin, R[col], color=c, marker="o", label=lab)
ax.set_ylabel("DI, all eight blocks"); ax.set_title("DI under three reference forecasts")
ax.legend(loc="lower left", fontsize=8)
save(fig, "R12_reference_forecast")
