"""A3. Duration test with equal observation windows (round 1 revision, comment R3.3).

Run from the project root, after script 03:
    analysis/.venv/bin/python analysis/17_duration_equal_window.py > analysis/17_duration_equal_window_output.txt

Table 6 of the paper (script 03, E2) scores contracts first published in 2024 and 2025 against an
amendment published by the end of 2025, so the observation window runs from 0 to 24 months. Here
every contract has the same horizon h, fully observed by the end of the record:
  h = 12 months: contracts first published in 2024; outcome: first amendment within 365 days.
  h = 6 months:  contracts first published January 2024 to June 2025; outcome: within 182 days.
Models are trained on Commonwealth contracts published 2019-2023 with the same h-month outcome.
Contracts first amended after h are left out (their recorded duration may be revised by an amendment
that is not the outcome). Rows as in Table 6, and the publication months of the two amended
groups (too little overlap for a month-matched comparison), and a balance table.
Rows 1 and 2 of each panel score the same contracts, so selection between groups cannot explain
their contrast.
Output: analysis/results/N3_equal_window.csv, N3_balance.csv
"""
import numpy as np, pandas as pd
import xgboost as xgb
from sklearn.metrics import roc_auc_score
from lib import *

C = load_contracts(); W = C[C.fed].copy()
rng = np.random.default_rng(SEED)
W["proc_class"] = method_class(W.procurement_method)


def auc_gain(y, pa, pb, mask, w=None, B=500):
    idx = np.where(mask)[0]; ww = None if w is None else w[idx]
    a = roc_auc_score(y[idx], pa[idx], sample_weight=ww); b = roc_auc_score(y[idx], pb[idx], sample_weight=ww); bs = []
    for _ in range(B):
        j = rng.choice(idx, len(idx)); wj = None if w is None else w[j]
        bs.append(roc_auc_score(y[j], pb[j], sample_weight=wj) - roc_auc_score(y[j], pa[j], sample_weight=wj))
    return a, b, b - a, np.percentile(bs, 2.5), np.percentile(bs, 97.5)


rows, bal = [], []
for h, lo_d, hi_d in [(365, "2024-01-01", "2024-12-31"), (182, "2024-01-01", "2025-06-30")]:
    lab = lambda df: ((df.ever_amended == 1) & (df.first_lag <= h)).astype(float).values
    tr = sample(W[W.yr.between(2019, 2023)], SEED); ytr = lab(tr)
    ev = W[(W.published_date >= lo_d) & (W.published_date <= hi_d)].copy()
    ev = ev[(ev.ever_amended == 0) | (ev.first_lag <= h)]               # amended after h left out
    y = lab(ev)
    Xtr, Xev, cols = encode(tr, ev, ytr, {})
    six = use_cols(cols, SIX)
    M0 = xgb.XGBClassifier(**HP).fit(Xtr[six], ytr); M1 = xgb.XGBClassifier(**HP).fit(Xtr[six + ["duration"]], ytr)
    p0 = M0.predict_proba(Xev[six])[:, 1]; p1 = M1.predict_proba(Xev[six + ["duration"]])[:, 1]
    rev = ((ev.a1_end - ev.contract_start).dt.days).values.astype(float)
    Xr = Xev.copy(); Xr["duration"] = np.where((y == 1) & ~np.isnan(rev), rev, Xev.duration.values)
    p1r = M1.predict_proba(Xr[six + ["duration"]])[:, 1]
    never = y == 0; amc = (y == 1) & (ev.overwritten.values == 0); amo = (y == 1) & (ev.overwritten.values == 1)
    clean, over = never | amc, never | amo
    # publication month of each contract, for the overlap of the two amended groups
    # strata: month of first publication (the lag to first amendment is already balanced; see the balance table)
    st = ev.published_date.dt.to_period("M").astype(str).values
    nc = pd.Series(st[amc]).value_counts(); no = pd.Series(st[amo]).value_counts()
    win = ev.published_date.max() - ev.published_date.min()
    # month overlap of the two amended groups: a month-matched comparison needs both groups in the same months
    okm = nc.index[(nc >= 30) & (no.reindex(nc.index).fillna(0) >= 30)]
    q1 = pd.Series(ev.loc[amc, "published_date"].dt.to_period("Q").astype(str).values).value_counts().sort_index()
    q2 = pd.Series(ev.loc[amo, "published_date"].dt.to_period("Q").astype(str).values).value_counts().sort_index()
    print("h = %d: publication months with at least 30 amended contracts in both groups: %d" % (h, len(okm)))
    print("   amended contracts by quarter of first publication (not overwritten | overwritten):")
    print(pd.concat([q1.rename("not overwritten"), q2.rename("overwritten")], axis=1).fillna(0).astype(int).T.to_string())
    for nm, mask, pb, ww in [("Parent not overwritten; duration as first published", clean, p1, None),
                             ("Same contracts; duration after first amendment", clean, p1r, None),
                             ("Parent overwritten; recorded duration", over, p1, None)]:
        a, b, g, lo, hi = auc_gain(y, p0, pb, mask, ww)
        rows.append({"horizon_days": h, "cohort": "%s to %s" % (lo_d, hi_d), "evaluation set": nm, "n_amended": int((mask & (y == 1)).sum()),
                     "n_not_amended": int((mask & never).sum()), "auc_six": a, "auc_six_duration": b, "gain": g, "lo": lo, "hi": hi})
    print("h = %d days: %d contracts, %d amended within h (%d not overwritten, %d overwritten)"
          % (h, len(ev), int(y.sum()), amc.sum(), amo.sum()), flush=True)
    # balance on observables between the not-overwritten and overwritten amended contracts
    feat = pd.DataFrame({"log value": ev.ly.values, "months since January 2024": (ev.published_date.dt.year.values - 2024) * 12 + ev.published_date.dt.month.values - 1,
                         "days to first amendment": ev.first_lag.values, "consultancy": ev.consult.values, "description length": ev.desc_len.values,
                         "open procedure": (ev.proc_class.values == "open").astype(float), "end date present": ev.has_end.values,
                         "publication lag (days)": ev.pub_lag.values, "log agency employees": np.log1p(ev.publisher_employees.values.astype(float)),
                         "six-block forecast": p0})
    for c in feat:
        a_, b_ = feat[c].values[amc].astype(float), feat[c].values[amo].astype(float)
        sd = np.sqrt((np.nanvar(a_) + np.nanvar(b_)) / 2)
        bal.append({"horizon_days": h, "variable": c, "not_overwritten_mean": np.nanmean(a_), "overwritten_mean": np.nanmean(b_),
                    "smd": (np.nanmean(a_) - np.nanmean(b_)) / sd if sd > 0 else np.nan})
    top = ev.agency_id.value_counts().index[:5]
    bal.append({"horizon_days": h, "variable": "share in the five largest agencies", "not_overwritten_mean": ev.agency_id[amc].isin(top).mean(),
                "overwritten_mean": ev.agency_id[amo].isin(top).mean(), "smd": np.nan})

R = pd.DataFrame(rows); R.to_csv(RES + "N3_equal_window.csv", index=False)
Bl = pd.DataFrame(bal); Bl.to_csv(RES + "N3_balance.csv", index=False)
print("\nN3. Contribution of duration to the amendment forecast with equal observation windows"); print(R.round(4).to_string(index=False))
print("\nN3. Amended contracts whose parent was not overwritten against those whose parent was (standardised mean differences)")
print(Bl.round(3).to_string(index=False))
E2 = pd.read_csv(RES + "E2_duration_first_published.csv")
print("\nTable 6 of the paper (unequal windows, script 03) for comparison"); print(E2.round(4).to_string(index=False))
