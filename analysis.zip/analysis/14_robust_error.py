"""Absolute-error measures with the placeholder values retained (Section 4.7; Appendix D).

Run from the project root, after script 06:
    analysis/.venv/bin/python analysis/14_robust_error.py > analysis/14_robust_error_output.txt
Question: do the trend over origins and the jurisdiction comparison depend on the exclusion of the
431 placeholder values when forecast error is measured with absolute instead of squared error?

Three variants at each origin, all eight blocks for the trend and the seven at-publication blocks
for the jurisdiction comparison (as in script 10):
    excluded  placeholder values excluded, squared-error objective (the main design)
    retained  placeholder values retained, squared-error objective (as in script 10)
    retained_l1  placeholder values retained, absolute-error objective
Measures on the logarithm of contract value:
    DI         1 - sum of squared errors / sum of squared deviations from the evaluation mean
    skill_abs  1 - sum of absolute errors / sum of absolute deviations from the evaluation median
    mae, medae mean and median absolute error;  rsd  residual standard error
Output: analysis/results/R3_robust_error.csv, R3_robust_trend.csv, R3_robust_jurisdiction.csv
"""
import numpy as np, pandas as pd
from lib import *

L1 = dict(HP, objective="reg:absoluteerror")


def skill_abs(y, p):
    y = np.asarray(y, float); p = np.asarray(p, float)
    return 1 - np.sum(np.abs(y - p)) / np.sum(np.abs(y - np.median(y)))


def measures(y, p):
    e = np.abs(np.asarray(y, float) - np.asarray(p, float))
    return {"di": di(y, p), "rsd": rsd(y, p), "skill_abs": skill_abs(y, p), "mae": float(e.mean()), "medae": float(np.median(e))}


C = load_contracts()
A = pd.read_pickle(CACHE + "contracts_all_values.pkl"); A = A[A.value > 0].copy()       # zero and negative values have no logarithm
A["ly"] = np.log(A.value); A["agency_id"] = A.publisher_name.fillna("NA")
print("Placeholder values (0 < value <= A$1) retained: %d contracts" % (A.value <= 1).sum())

VARIANTS = [("excluded", C, HP), ("retained", A, HP), ("retained_l1", A, L1)]
rows, pool = [], []
for Y in ORIGINS:
    for nm, D, hp in VARIANTS:
        tr = sample(D[D.yr.between(Y - 5, Y - 1)], SEED + Y); ev = D[D.yr == Y]
        ytr, yev = tr.ly.values, ev.ly.values
        Xtr, Xev, cols = encode(tr, ev, ytr, HIST)
        p8 = fit_predict(Xtr, ytr, Xev, use_cols(cols, EIGHT), hp=hp)
        p7 = fit_predict(Xtr, ytr, Xev, use_cols(cols, SEVEN), hp=hp)
        r = {"origin": Y, "variant": nm, "n": len(ev), "n_placeholders": int((ev.value <= 1).sum()), **measures(yev, p8),
             "sd": float(np.std(yev)), "mad": float(np.mean(np.abs(yev - np.median(yev))))}
        rows.append(r)
        pool.append(pd.DataFrame({"variant": nm, "origin": Y, "fed": ev.fed.values, "y": yev, "p": p7}))
        print(Y, nm, {k: round(float(v), 4) for k, v in r.items() if k not in ("origin", "variant")}, flush=True)
R = pd.DataFrame(rows); R.to_csv(RES + "R3_robust_error.csv", index=False)

# ------------------------------------------------------------------ trend over the eleven origins
T = []
for nm, g in R.groupby("variant", sort=False):
    for m in ["di", "skill_abs", "rsd", "mae", "medae", "sd", "mad"]:
        tau, p, slope = mann_kendall(g.origin, g[m])
        T.append({"variant": nm, "measure": m, "first": g[m].iloc[0], "last": g[m].iloc[-1], "min": g[m].min(), "max": g[m].max(),
                  "tau": tau, "mk_p": p, "sen_slope": slope})
T = pd.DataFrame(T); T.to_csv(RES + "R3_robust_trend.csv", index=False)
print("\nTrend over the eleven origins, all eight blocks"); print(T.round(4).to_string(index=False))

# ------------------------------------------------------------------ jurisdiction, seven at-publication blocks
# pooled over the last three origins (the design of Section 4.5, script 08) and over all eleven (as in script 10)
Q = pd.concat(pool); J = []
for pl, sub in [("last three origins", Q[Q.origin.isin(ORIGINS[-3:])]), ("all eleven origins", Q)]:
    for nm, g in sub.groupby("variant", sort=False):
        for fed, h in g.groupby("fed"):
            J.append({"pool": pl, "variant": nm, "group": "Commonwealth" if fed else "State and territory", "n": len(h),
                      **measures(h.y.values, h.p.values), "sd": float(np.std(h.y)), "mad": float(np.mean(np.abs(h.y - np.median(h.y))))})
J = pd.DataFrame(J); J.to_csv(RES + "R3_robust_jurisdiction.csv", index=False)
print("\nJurisdiction comparison, seven at-publication blocks"); print(J.round(4).to_string(index=False))
for (pl, nm), g in J.groupby(["pool", "variant"], sort=False):
    c, s = g[g.group == "Commonwealth"].iloc[0], g[g.group != "Commonwealth"].iloc[0]
    print("   %s, %s: difference (Commonwealth minus state and territory) in DI %+.3f, in absolute-error skill %+.3f, in residual SD %+.3f, in MAE %+.3f, in median absolute error %+.3f"
          % (pl, nm, c.di - s.di, c.skill_abs - s.skill_abs, c.rsd - s.rsd, c.mae - s.mae, c.medae - s.medae))
