"""A5. Sensitivity of the value-target results to the training subsample and the learner seed
(round 1 revision, comment R2.5).

Run from the project root:
    analysis/.venv/bin/python analysis/19_subsample_seeds.py > analysis/19_subsample_seeds_output.txt
Design: the eleven-origin series of script 06 for eight, seven and six blocks is repeated with ten
further seeds. Seed s draws the 100,000-row training subsample with random_state SEED + origin +
1000 s (script 06 uses SEED + origin) and fits the learner with random_state SEED + s; everything
else is unchanged. A second part fits the same models on the full five-year training window, without
subsampling, at three origins.
Output: analysis/results/N5_seeds_by_origin.csv, N5_seeds_summary.csv, N5_no_subsample.csv
The by-origin file is written after every seed, and seeds already present are skipped on a rerun.
"""
import os, time
import numpy as np, pandas as pd
from lib import *

C = load_contracts()
SEEDS = list(range(1, 11))
SETS = {"all8": EIGHT, "seven": SEVEN, "six": SIX}
OUT = RES + "N5_seeds_by_origin.csv"


def one_origin(Y, tr, hp):
    ev = C[C.yr == Y]
    ytr, yev = tr.ly.values, ev.ly.values
    Xtr, Xev, cols = encode(tr, ev, ytr, HIST)
    r = {"origin": Y, "n_train": len(tr), "n_eval": len(ev)}
    for nm, b in SETS.items():
        p = fit_predict(Xtr, ytr, Xev, use_cols(cols, b), hp=hp)
        r[nm] = di(yev, p); r[nm + "_rsd"] = rsd(yev, p)
    r["floor"] = (r["all8"] - r["seven"]) / r["all8"]
    r["ceiling"] = (r["all8"] - r["six"]) / r["all8"]
    return r


done = pd.read_csv(OUT) if os.path.exists(OUT) else pd.DataFrame()
rows = done.to_dict("records")
for s in SEEDS:
    if len(done) and s in set(done.seed):
        print("seed", s, "already done; skipped", flush=True); continue
    t0 = time.time(); hp = dict(HP, random_state=SEED + s)
    for Y in ORIGINS:
        tr = sample(C[C.yr.between(Y - 5, Y - 1)], SEED + Y + 1000 * s)
        r = one_origin(Y, tr, hp); r["seed"] = s; rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print("seed %d done in %.0f s" % (s, time.time() - t0), flush=True)

R = pd.DataFrame(rows)
# the published series (script 06) as seed 0
M1 = pd.read_csv(RES + "M1_di_by_origin.csv")
M0 = M1[["origin", "all8", "seven", "six", "all8_rsd", "seven_rsd", "six_rsd", "floor", "ceiling"]].assign(seed=0)
A = pd.concat([M0, R[M0.columns]], ignore_index=True)

summ = []
for s, g in A.groupby("seed"):
    f = g[g.origin.isin(FULL)]
    t8 = mann_kendall(g.origin, g.all8); t7 = mann_kendall(g.origin, g.seven); tr_ = mann_kendall(g.origin, g.all8_rsd)
    summ.append({"seed": s, "mean_all8": g.all8.mean(), "mean_seven": g.seven.mean(), "mean_six": g.six.mean(),
                 "floor_mean": f.floor.mean(), "floor_min": f.floor.min(), "floor_max": f.floor.max(),
                 "ceiling_mean": f.ceiling.mean(), "mk_p_all8": t8[1], "sen_all8": t8[2], "mk_p_seven": t7[1],
                 "mk_p_rsd_all8": tr_[1], "last3_minus_first3": g.all8.iloc[-3:].mean() - g.all8.iloc[:3].mean()})
S = pd.DataFrame(summ); S.to_csv(RES + "N5_seeds_summary.csv", index=False)
print("\nN5. Summary by seed (seed 0 = script 06)"); print(S.round(4).to_string(index=False))
print("\nSpread across the eleven seeds (min, max, SD):")
for c in ["mean_all8", "floor_mean", "ceiling_mean", "mk_p_all8", "mk_p_rsd_all8", "last3_minus_first3"]:
    print("  %-20s %.4f  %.4f  %.4f" % (c, S[c].min(), S[c].max(), S[c].std()))
print("  trend in DI (all eight) significant at 0.05 for %d of %d seeds; residual SD trend significant for %d"
      % ((S.mk_p_all8 < 0.05).sum(), len(S), (S.mk_p_rsd_all8 < 0.05).sum()))
W = A.groupby("origin")[["all8", "seven", "six", "floor", "ceiling"]].agg(["min", "max", "std"])
print("\nRange across seeds by origin"); print(W.round(4).to_string())

# ------------------------------------------------------------------ no subsampling, three origins
NS = []
for Y in [2017, 2021, 2025]:
    t0 = time.time()
    r = one_origin(Y, C[C.yr.between(Y - 5, Y - 1)], HP)
    m = M1.set_index("origin").loc[Y]
    r.update({"all8_sub": m.all8, "seven_sub": m.seven, "six_sub": m.six, "floor_sub": m.floor, "ceiling_sub": m.ceiling})
    NS.append(r); print("no subsample", Y, "n_train", r["n_train"], "%.0f s" % (time.time() - t0), flush=True)
NS = pd.DataFrame(NS); NS.to_csv(RES + "N5_no_subsample.csv", index=False)
print("\nN5. Full training window (no subsampling) against the 100,000-row subsample"); print(NS.round(4).to_string(index=False))
