"""A4. Simpler forecasting models (round 1 revision, comments E4, R3.4).

Run from the project root, after scripts 03, 06 and 09:
    analysis/.venv/bin/python analysis/18_simple_baselines.py > analysis/18_simple_baselines_output.txt

Value target, eleven origins, same training samples and features as script 06:
  - Group-mean lookup: the training mean of log value by product category and buying agency, shrunk
    toward the category mean and then toward the overall mean (m = 20 at each level). Uses no other field.
  - Ridge regression (alpha = 1) on the same encoded features as the boosted trees, for eight, seven and
    six blocks. Linear models get, in addition: signed log1p of the skewed numeric fields (duration,
    publication lag, agency employees, description length), median imputation with a missing-value
    indicator, and standardisation, all fitted on training rows.
Amendment target, seven origins as script 09: logistic regression (L2, C = 1) for six blocks, six blocks
plus duration, and seven blocks; and the duration test of Table 6 (script 03, E2) refitted with it.
Output: analysis/results/N4_value_by_origin.csv, N4_value_summary.csv, N4_amend_by_origin.csv, N4_duration_test.csv
"""
import numpy as np, pandas as pd
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import roc_auc_score
from lib import *

SKEW = ["duration", "pub_lag", "publisher_employees", "desc_len"]


class Linear:
    """Preprocessing for the linear models, fitted on training rows."""

    def __init__(self, Xtr, use):
        self.use = use; X = Xtr[use].astype(float).copy()
        for c in SKEW:
            if c in X: X[c] = np.sign(X[c]) * np.log1p(np.abs(X[c]))
        self.na = [c for c in use if X[c].isna().any()]
        self.med = X.median(); X = self._fill(X)
        self.mu, self.sd = X.mean(), X.std().replace(0, 1)

    def _fill(self, X):
        for c in self.na: X[c + "_missing"] = X[c].isna().astype(float)
        return X.fillna(self.med)

    def __call__(self, Xd):
        X = Xd[self.use].astype(float).copy()
        for c in SKEW:
            if c in X: X[c] = np.sign(X[c]) * np.log1p(np.abs(X[c]))
        X = self._fill(X)
        return ((X - self.mu) / self.sd).values


def ridge_pred(Xtr, y, Xev, use):
    T = Linear(Xtr, use); return Ridge(alpha=1.0).fit(T(Xtr), y).predict(T(Xev))


def logit_pred(Xtr, y, Xev, use):
    T = Linear(Xtr, use); return LogisticRegression(C=1.0, max_iter=3000).fit(T(Xtr), y).predict_proba(T(Xev))[:, 1]


def lookup(tr, ev, y, m=20.0):
    g0 = y.mean(); d = pd.DataFrame({"c": tr.category_code.fillna("NA").values, "a": tr.agency_id.values, "y": y})
    s1 = d.groupby("c").y.agg(["sum", "count"]); mc = (s1["sum"] + g0 * m) / (s1["count"] + m)
    s2 = d.groupby(["c", "a"]).y.agg(["sum", "count"])
    c_ev = ev.category_code.fillna("NA").values; a_ev = ev.agency_id.values
    prior = mc.reindex(c_ev).fillna(g0).values
    k = pd.MultiIndex.from_arrays([c_ev, a_ev]); ss, cc = s2["sum"].reindex(k).fillna(0).values, s2["count"].reindex(k).fillna(0).values
    return (ss + prior * m) / (cc + m)


C = load_contracts()
M1 = pd.read_csv(RES + "M1_di_by_origin.csv").set_index("origin")
SETS = {"all8": EIGHT, "seven": SEVEN, "six": SIX}
rows = []
for Y in ORIGINS:
    tr = sample(C[C.yr.between(Y - 5, Y - 1)], SEED + Y); ev = C[C.yr == Y]
    ytr, yev = tr.ly.values, ev.ly.values
    Xtr, Xev, cols = encode(tr, ev, ytr, HIST)
    r = {"origin": Y}
    p = lookup(tr, ev, ytr); r["lookup"] = di(yev, p); r["lookup_rsd"] = rsd(yev, p)
    for nm, b in SETS.items():
        p = ridge_pred(Xtr, ytr, Xev, use_cols(cols, b)); r["ridge_" + nm] = di(yev, p); r["ridge_" + nm + "_rsd"] = rsd(yev, p)
        r["xgb_" + nm] = M1.loc[Y, nm]; r["xgb_" + nm + "_rsd"] = M1.loc[Y, nm + "_rsd"]
    for L in ["ridge", "xgb"]:
        r[L + "_floor"] = (r[L + "_all8"] - r[L + "_seven"]) / r[L + "_all8"]
        r[L + "_ceiling"] = (r[L + "_all8"] - r[L + "_six"]) / r[L + "_all8"]
    rows.append(r); print(Y, {k: round(v, 4) for k, v in r.items() if k in ("lookup", "ridge_all8", "xgb_all8", "ridge_floor", "ridge_ceiling")}, flush=True)
R = pd.DataFrame(rows); R.to_csv(RES + "N4_value_by_origin.csv", index=False)
S = []
F = R[R.origin.isin(FULL)]
for nm, col in [("Group-mean lookup", "lookup"), ("Ridge, eight blocks", "ridge_all8"), ("Ridge, seven blocks", "ridge_seven"), ("Ridge, six blocks", "ridge_six"),
                ("Boosted trees, eight blocks", "xgb_all8"), ("Boosted trees, seven blocks", "xgb_seven"), ("Boosted trees, six blocks", "xgb_six")]:
    tau, p, s = mann_kendall(R.origin, R[col]); tr_ = mann_kendall(R.origin, R[col + "_rsd"])
    S.append({"model": nm, "mean_DI": R[col].mean(), "first": R[col].iloc[0], "last": R[col].iloc[-1], "mk_p_DI": p, "sen_DI": s,
              "mean_rsd": R[col + "_rsd"].mean(), "mk_p_rsd": tr_[1]})
for L, nm in [("ridge", "Ridge"), ("xgb", "Boosted trees")]:
    S.append({"model": nm + ": floor (mean over 2015-2023)", "mean_DI": F[L + "_floor"].mean(), "first": F[L + "_floor"].min(), "last": F[L + "_floor"].max()})
    S.append({"model": nm + ": ceiling (mean over 2015-2023)", "mean_DI": F[L + "_ceiling"].mean(), "first": F[L + "_ceiling"].min(), "last": F[L + "_ceiling"].max()})
S = pd.DataFrame(S); S.to_csv(RES + "N4_value_summary.csv", index=False)
print("\nN4. Value target: simpler models beside the boosted trees (floor/ceiling rows: mean, min, max)"); print(S.round(4).to_string(index=False))

# ------------------------------------------------------------------ amendment target
W = C[C.fed].copy()
T1 = pd.read_csv(RES + "T1_amendment_by_origin.csv").set_index("origin"); T2 = pd.read_csv(RES + "T2_duration_test.csv").set_index("origin")
rows = []
for Y in AM_ORIGINS:
    tr = sample(W[W.yr.between(Y - 7, Y - 3)], SEED + Y); ev = W[W.yr == Y]
    ytr, yev = tr.amended24.values.astype(float), ev.amended24.values.astype(float)
    Xtr, Xev, cols = encode(tr, ev, ytr, {})
    six, seven = use_cols(cols, SIX), use_cols(cols, SEVEN)
    p6, p6d, p7 = logit_pred(Xtr, ytr, Xev, six), logit_pred(Xtr, ytr, Xev, six + ["duration"]), logit_pred(Xtr, ytr, Xev, seven)
    rows.append({"origin": Y, "base_rate": yev.mean(), "logit_auc_six": roc_auc_score(yev, p6), "logit_auc_six_duration": roc_auc_score(yev, p6d),
                 "logit_gain": roc_auc_score(yev, p6d) - roc_auc_score(yev, p6), "logit_auc_seven": roc_auc_score(yev, p7), "logit_DI_seven": di(yev, p7),
                 "xgb_auc_six": T2.loc[Y, "auc_six"], "xgb_auc_six_duration": T2.loc[Y, "auc_six_duration"], "xgb_gain": T2.loc[Y, "gain"],
                 "xgb_auc_seven": T1.loc[Y, "auc"], "xgb_DI_seven": T1.loc[Y, "DI"]})
    print(Y, {k: round(v, 4) for k, v in rows[-1].items() if k.startswith("logit")}, flush=True)
A = pd.DataFrame(rows); A.to_csv(RES + "N4_amend_by_origin.csv", index=False)
print("\nN4. Amendment target, logistic regression beside the boosted trees"); print(A.round(4).to_string(index=False))
print("  means:", A.drop(columns="origin").mean().round(4).to_dict())

# duration test of Table 6 with logistic regression (same design as script 03, E2)
rng = np.random.default_rng(SEED)
tr = sample(W[W.yr.between(2019, 2023)], SEED); ev = W[W.yr >= 2024].copy()
ev = ev[(ev.ever_amended == 0) | (ev.a1_yr >= 2024)]
ytr = tr.amended24.values.astype(float)
Xtr, Xev, cols = encode(tr, ev, ytr, {}); six = use_cols(cols, SIX)
T0 = Linear(Xtr, six); L0 = LogisticRegression(C=1.0, max_iter=3000).fit(T0(Xtr), ytr)
T1_ = Linear(Xtr, six + ["duration"]); L1 = LogisticRegression(C=1.0, max_iter=3000).fit(T1_(Xtr), ytr)
p0 = L0.predict_proba(T0(Xev))[:, 1]; p1 = L1.predict_proba(T1_(Xev))[:, 1]
Xr = Xev.copy(); rev = ((ev.a1_end - ev.contract_start).dt.days).values.astype(float)
Xr["duration"] = np.where((ev.ever_amended.values == 1) & ~np.isnan(rev), rev, Xev.duration.values)
p1r = L1.predict_proba(T1_(Xr))[:, 1]
y = ev.ever_amended.values; never = y == 0
clean = never | (ev.overwritten.values == 0); over = never | (ev.overwritten.values == 1)
rows = []
for nm, mask, pb in [("Parent not overwritten; duration as first published", clean, p1),
                     ("Same contracts; duration after first amendment", clean, p1r),
                     ("Parent overwritten; recorded duration", over, p1)]:
    idx = np.where(mask)[0]; a, b = roc_auc_score(y[idx], p0[idx]), roc_auc_score(y[idx], pb[idx]); bs = []
    for _ in range(500):
        j = rng.choice(idx, len(idx)); bs.append(roc_auc_score(y[j], pb[j]) - roc_auc_score(y[j], p0[j]))
    rows.append({"evaluation set": nm, "n_amended": int(y[mask].sum()), "auc_six": a, "auc_six_duration": b, "gain": b - a,
                 "lo": np.percentile(bs, 2.5), "hi": np.percentile(bs, 97.5)})
D = pd.DataFrame(rows); D.to_csv(RES + "N4_duration_test.csv", index=False)
print("\nN4. Duration test (Table 6) with logistic regression"); print(D.round(4).to_string(index=False))
