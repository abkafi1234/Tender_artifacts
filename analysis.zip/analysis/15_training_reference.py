"""A1. DI with a reference forecast known at the forecast origin (round 1 revision, comments E2, R2.3).

Run from the project root, after scripts 06 and 09:
    analysis/.venv/bin/python analysis/15_training_reference.py > analysis/15_training_reference_output.txt
DI in the paper (Eq. 1) is the MSE skill score with the evaluation-set mean as the reference forecast,
the out-of-sample R^2 convention. That mean is not known at the forecast origin. This script keeps the
numerator (the forecast errors, from the saved predictions) and replaces the reference with
  (a) "train": the mean of the target over the five-year training window, known at the origin;
  (b) "train_cat": the training-window mean by product category (category_code), shrunk toward the
      training mean with the same smoothing (m = 20) as the target encoding; a stronger naive forecast.
      For the amendment target the same with the training base rate.
Reported: the DI series and trend, floor and ceiling, the jurisdiction comparison (Section 4.5), and
the Brier skill score on the amendment target, under each reference.
Output: analysis/results/N1_reference_by_origin.csv, N1_reference_trend.csv, N1_reference_jurisdiction.csv,
        N1_reference_amendment.csv
"""
import numpy as np, pandas as pd
from lib import *

C = load_contracts()
PV = pd.read_pickle(CACHE + "preds_value.pkl")
SETS = {"all8": "p_all8", "seven": "p_seven", "six": "p_six"}
REFS = ["ev", "train", "train_cat"]
M = 20.0


def cat_reference(trw, ev, ycol, prior):
    s = trw.groupby(trw.category_code.fillna("NA"))[ycol].agg(["sum", "count"])
    return ((s["sum"] + prior * M) / (s["count"] + M)).reindex(ev.category_code.fillna("NA")).fillna(prior).values


# ------------------------------------------------------------------ value target, by origin
rows, refcols = [], []
for Y in ORIGINS:
    q = PV[PV.origin == Y]; ev = C.loc[q.index]; y = q.y.values
    trw = C[C.yr.between(Y - 5, Y - 1)]
    m_tr = trw.ly.mean()
    ref = {"ev": np.full(len(y), y.mean()), "train": np.full(len(y), m_tr), "train_cat": cat_reference(trw, ev, "ly", m_tr)}
    refcols.append(pd.DataFrame({"ref_train": ref["train"], "ref_train_cat": ref["train_cat"]}, index=q.index))
    r = {"origin": Y, "n_eval": len(y), "eval_mean": y.mean(), "train_mean": m_tr,
         "mean_shift": y.mean() - m_tr, "total_sd": y.std()}
    for rf in REFS:
        sst = np.sum((y - ref[rf]) ** 2); r["mse_ref_" + rf] = sst / len(y)
        for nm, col in SETS.items():
            r[nm + "_" + rf] = 1 - np.sum((y - q[col].values) ** 2) / sst
        r["floor_" + rf] = (r["all8_" + rf] - r["seven_" + rf]) / r["all8_" + rf]
        r["ceiling_" + rf] = (r["all8_" + rf] - r["six_" + rf]) / r["all8_" + rf]
    # share of the training-reference MSE that is due to the shift of the mean between windows
    r["shift_share_of_ref_mse"] = (y.mean() - m_tr) ** 2 / r["mse_ref_train"]
    r["rsd_all8"] = rsd(y, q.p_all8.values)
    rows.append(r)
R = pd.DataFrame(rows); R.to_csv(RES + "N1_reference_by_origin.csv", index=False)
REF = pd.concat(refcols)
print("N1. DI of the eight-block forecast under three reference forecasts")
print(R[["origin", "eval_mean", "train_mean", "mean_shift", "total_sd", "all8_ev", "all8_train", "all8_train_cat", "shift_share_of_ref_mse"]].round(4).to_string(index=False))
F = R[R.origin.isin(FULL)]
print("\nFloor and ceiling over the nine fully observed origins (mean, min, max)")
for rf in REFS:
    print("  %-10s floor %.1f%% (%.1f%% to %.1f%%) | ceiling %.1f%% (%.1f%% to %.1f%%) | mean DI all8 %.3f seven %.3f six %.3f"
          % (rf, 100 * F["floor_" + rf].mean(), 100 * F["floor_" + rf].min(), 100 * F["floor_" + rf].max(),
             100 * F["ceiling_" + rf].mean(), 100 * F["ceiling_" + rf].min(), 100 * F["ceiling_" + rf].max(),
             R["all8_" + rf].mean(), R["seven_" + rf].mean(), R["six_" + rf].mean()))

# trend tests and the last-three-minus-first-three difference, by reference
T = []
for rf in REFS:
    for nm in SETS:
        tau, p, s = mann_kendall(R.origin, R[nm + "_" + rf])
        T.append({"reference": rf, "series": nm, "first": R[nm + "_" + rf].iloc[0], "last": R[nm + "_" + rf].iloc[-1],
                  "mean": R[nm + "_" + rf].mean(), "tau": tau, "mk_p": p, "sen_slope": s,
                  "last3_minus_first3": R[nm + "_" + rf].iloc[-3:].mean() - R[nm + "_" + rf].iloc[:3].mean()})
tau, p, s = mann_kendall(R.origin, R.mse_ref_train)
T.append({"reference": "train", "series": "MSE of the reference forecast", "first": R.mse_ref_train.iloc[0], "last": R.mse_ref_train.iloc[-1],
          "mean": R.mse_ref_train.mean(), "tau": tau, "mk_p": p, "sen_slope": s})
T = pd.DataFrame(T); T.to_csv(RES + "N1_reference_trend.csv", index=False)
print("\nTrend over the eleven origins (Mann-Kendall)"); print(T.round(4).to_string(index=False))

# ------------------------------------------------------------------ jurisdiction comparison (as script 08, G1)
E = C.loc[PV.index, ["fed", "agency_id"]].copy()
E["y"], E["p"], E["origin"] = PV.y.values, PV.p_seven.values, PV.origin.values
E = E.join(REF)
POOL = ORIGINS[-3:]
E = E[E.origin.isin(POOL)].copy(); E["juris"] = np.where(E.fed, "Commonwealth", "State and territory")
# group-specific training mean: the mean of the training window of each origin within the group
gm = {(Y, f): C[C.yr.between(Y - 5, Y - 1) & (C.fed == f)].ly.mean() for Y in POOL for f in [True, False]}
E["ref_train_group"] = [gm[(o, f)] for o, f in zip(E.origin, E.fed)]
codes = pd.factorize(E.agency_id.values)[0]; K = codes.max() + 1
rng = np.random.default_rng(SEED)
Wb = np.stack([np.bincount(rng.integers(0, K, K), minlength=K) for _ in range(NBOOT)]).astype(float)
J, draws = [], {}
for g, idx in E.groupby("juris").indices.items():
    y, p, c = E.y.values[idx], E.p.values[idx], codes[idx]
    sse = np.bincount(c, weights=(y - p) ** 2, minlength=K)
    out = {"group": g, "n": len(y), "resid_sd": rsd(y, p)}
    # evaluation-set mean of the group (the paper's DI) and three references known at the origin
    for rf, refv in [("ev", np.full(len(y), y.mean())), ("train_group", E.ref_train_group.values[idx]),
                     ("train_pooled", E.ref_train.values[idx]), ("train_cat", E.ref_train_cat.values[idx])]:
        if rf == "ev":
            n = np.bincount(c, minlength=K).astype(float); sy = np.bincount(c, weights=y, minlength=K); syy = np.bincount(c, weights=y * y, minlength=K)
            d = 1 - (Wb @ sse) / (Wb @ syy - (Wb @ sy) ** 2 / (Wb @ n))
        else:
            sr = np.bincount(c, weights=(y - refv) ** 2, minlength=K)
            with np.errstate(divide="ignore", invalid="ignore"):
                d = 1 - (Wb @ sse) / (Wb @ sr)
        out["DI_" + rf] = 1 - np.sum((y - p) ** 2) / np.sum((y - refv) ** 2)
        out["rmse_ref_" + rf] = np.sqrt(np.mean((y - refv) ** 2))
        draws[(g, rf)] = d
    J.append(out)
J = pd.DataFrame(J)
for rf in ["ev", "train_group", "train_pooled", "train_cat"]:
    d = draws[("Commonwealth", rf)] - draws[("State and territory", rf)]
    J.loc[len(J)] = {"group": "difference (%s)" % rf, "DI_" + rf: J["DI_" + rf].iloc[0] - J["DI_" + rf].iloc[1]}
    J.loc[len(J) - 1, "lo"], J.loc[len(J) - 1, "hi"] = ci(d); J.loc[len(J) - 1, "p"] = boot_p(d)
J.to_csv(RES + "N1_reference_jurisdiction.csv", index=False)
print("\nJurisdiction comparison, seven blocks, origins %d to %d pooled, under each reference" % (POOL[0], POOL[-1]))
print(J.round(4).to_string(index=False))

# ------------------------------------------------------------------ amendment target: Brier skill score
PA = pd.read_pickle(CACHE + "preds_amend.pkl")
W = C[C.fed].copy(); W["amended24"] = W.amended24.astype(float)
A = []
for Y in AM_ORIGINS:
    q = PA[PA.origin == Y]; ev = W.loc[q.index]; y = q.y.values; p = q.p.values
    trw = W[W.yr.between(Y - 7, Y - 3)]; b_tr = trw.amended24.mean(); b = y.mean()
    rc = cat_reference(trw, ev, "amended24", b_tr)
    brier = np.mean((y - p) ** 2)
    A.append({"origin": Y, "n": len(y), "base_rate_eval": b, "base_rate_train": b_tr, "brier": brier,
              "BSS_ev": 1 - brier / (b * (1 - b)), "BSS_train": 1 - brier / np.mean((y - b_tr) ** 2),
              "BSS_train_cat": 1 - brier / np.mean((y - rc) ** 2)})
A = pd.DataFrame(A); A.to_csv(RES + "N1_reference_amendment.csv", index=False)
print("\nAmendment target: Brier skill score under each reference (BSS_ev is the DI of the paper)"); print(A.round(4).to_string(index=False))
for c in ["BSS_ev", "BSS_train", "BSS_train_cat"]:
    tau, p, s = mann_kendall(A.origin, A[c]); print("  %-14s mean %.3f | Mann-Kendall p %.3f" % (c, A[c].mean(), p))
