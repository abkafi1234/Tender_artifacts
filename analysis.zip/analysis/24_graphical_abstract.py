"""Graphical abstract for the revised article (2200 x 1120 px PNG and a vector PDF).

Run from the project root, after scripts 01 to 22:
    analysis/.venv/bin/python analysis/24_graphical_abstract.py "<path to Manuscript_concise/graphical_abstract>"
Design (archive/records/planning/graphical_abstract_research_2026-11-18.md): one key message; three stages read
left to right and joined by arrows; pictograms rather than charts; at most three results; the colour code of the
article's figures (blue: on the notice at publication; orange: added afterwards). Every number is read from
analysis/results/.
"""
import os, sys
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon, Rectangle

OUT = sys.argv[1] if len(sys.argv) > 1 else "analysis/figures"
os.makedirs(OUT, exist_ok=True)
R = "analysis/results/"

# ---------------------------------------------------------------- numbers
M3 = pd.read_csv(R + "M3_hindsight.csv"); F = M3[M3.origin <= 2023]
TS = pd.read_csv(R + "N2_tiers_summary.csv").set_index("tier")
floor, ceil = F.floor.mean(), F.ceiling.mean()
up0 = TS.loc["(iii) inferred: upper bound, q = 0", "value"]
T2 = pd.read_csv(R + "T2_duration_test.csv")
auc0, auc1 = T2.auc_six.mean(), T2.auc_six_duration.mean()
G3 = pd.read_csv(R + "G3_jurisdiction.csv"); g = G3[G3.spec == "Full field set"].set_index("group")
di_c, di_s = g.loc["Commonwealth", "DI"], g.loc["State and territory", "DI"]
rs_c, rs_s = g.loc["Commonwealth", "resid_sd"], g.loc["State and territory", "resid_sd"]
n_contracts = int(pd.read_csv(R + "D1_sample.csv").set_index("step").records["Contracts analysed"])
pct = lambda x: f"{100*x:.1f}%".replace(".0%", "%")

# ---------------------------------------------------------------- style
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"]})
INK, MUTED, LINE, PANEL = "#16191d", "#5c636d", "#c9ced5", "#f3f4f6"
BLUE, ORANGE, ORANGE_L, BLUE_L = "#2a78d6", "#eb6834", "#f7c2a9", "#cfe1f7"
W, H = 110, 56
fig = plt.figure(figsize=(11, 5.6), dpi=200)
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis("off")


def box(x, y, w, h, fc, ec="none", lw=0, r=1.0, z=1, **k):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=%s" % r, fc=fc, ec=ec, lw=lw, zorder=z, **k))


def t(x, y, s, size=9, color=INK, weight="normal", ha="left", va="center", **k):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight, ha=ha, va=va, zorder=5, **k)


def arrow(x0, y0, x1, y1, color=MUTED, lw=1.6, ms=12):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=ms, color=color, lw=lw,
                                 shrinkA=0, shrinkB=0, zorder=4))


def chevron(x, y):
    ax.add_patch(Polygon([[x, y + 2.6], [x + 2.2, y], [x, y - 2.6]], closed=True, fc=LINE, ec="none", zorder=3))


def doc(x, y, w, h, date, col, label, faded=False):
    """A notice pictogram with a folded corner, text lines and an end-date field."""
    c = 1.6
    ec = LINE if faded else INK
    ax.add_patch(Polygon([[x, y], [x + w, y], [x + w, y + h - c], [x + w - c, y + h], [x, y + h]], closed=True,
                         fc="white", ec=ec, lw=1.0, zorder=2, ls="--" if faded else "-"))
    ax.add_patch(Polygon([[x + w - c, y + h], [x + w - c, y + h - c], [x + w, y + h - c]], closed=True, fc=LINE, ec=ec, lw=0.8, zorder=3))
    for i in range(3):
        ax.plot([x + 0.9, x + w - (2.6 if i == 0 else 0.9)], [y + h - 1.8 - 1.25 * i] * 2, color=LINE, lw=1.4, zorder=3)
    box(x + 0.7, y + 0.8, w - 1.4, 2.6, BLUE_L if col == BLUE else ORANGE_L, ec=col, lw=1.0, r=0.4, z=3)
    t(x + w / 2, y + 2.1, "ends " + date, 7.6, INK, ha="center", weight="bold")
    t(x + w / 2, y - 1.4, label, 7.6, MUTED, ha="center")


# ---------------------------------------------------------------- headline
t(2, 52.6, "Forecasts built on today's administrative record can use information", 15.5, weight="bold")
t(2, 49.3, "that did not exist when the forecast would have been made", 15.5, weight="bold")
t(108, 52.6, "Australian procurement records, 2010–2025", 8.6, MUTED, ha="right")
t(108, 50.0, f"{n_contracts:,} contracts, one row per contract", 8.6, MUTED, ha="right")

for x, w in [(2, 29), (35, 26), (65, 43)]:
    box(x, 2, w, 43.5, PANEL)
chevron(31.9, 24); chevron(61.9, 24)

# ---------------------------------------------------------------- 1. the record is rewritten
t(4, 42.3, "1", 13, ORANGE, weight="bold"); t(6.6, 42.3, "The record is rewritten", 11.5, weight="bold")
doc(4.5, 26.0, 9.2, 11.0, "Jun 2024", BLUE, "notice published")
doc(19.0, 26.0, 9.2, 11.0, "Mar 2025", ORANGE, "amendment")
arrow(14.3, 31.5, 18.4, 31.5)
doc(4.5, 10.0, 9.2, 10.4, "Mar 2025", ORANGE, "notice as shown today")
doc(19.0, 10.0, 9.2, 10.4, "Jun 2024", BLUE, "first version: not kept", faded=True)
arrow(9.1, 23.6, 9.1, 20.9, color=ORANGE)
t(10.1, 22.0, "overwritten", 7.8, ORANGE, weight="bold")
t(16.5, 4.3, "Earlier vintages are lost, so the usual\nreal-time comparison cannot be made", 7.8, MUTED, ha="center")

# ---------------------------------------------------------------- 2. one learner, two information sets
t(37, 42.3, "2", 13, ORANGE, weight="bold"); t(39.6, 42.3, "Same forecast, two inputs", 11.5, weight="bold")
box(37.5, 31.0, 21, 6.4, "white", ec=BLUE, lw=1.6, r=0.8)
t(48, 35.2, "Fields as first published", 9, BLUE, weight="bold", ha="center"); t(48, 32.8, "known at the forecast origin", 7.8, MUTED, ha="center")
box(37.5, 22.4, 21, 6.4, "white", ec=ORANGE, lw=1.6, r=0.8)
t(48, 26.6, "Fields as recorded today", 9, ORANGE, weight="bold", ha="center"); t(48, 24.2, "include later revisions", 7.8, MUTED, ha="center")
box(40.5, 10.8, 15, 7.2, INK, r=0.8)
t(48, 15.6, "Gradient-boosted", 8.6, "white", weight="bold", ha="center"); t(48, 13.2, "rolling origins 2015–2025", 7.6, "white", ha="center")
arrow(44, 22.0, 44, 18.4); arrow(52, 22.0, 52, 18.4)
t(48, 6.2, "Skill score (DI) and residual error,\none row per contract", 7.8, MUTED, ha="center")
arrow(48, 10.4, 48, 8.4)

# ---------------------------------------------------------------- 3. what changes
t(67, 42.3, "3", 13, ORANGE, weight="bold"); t(69.6, 42.3, "What the revisions add", 11.5, weight="bold")

# 3a. hindsight share
t(68, 37.4, "Share of skill added after publication", 9.2, weight="bold")
x0, xw, y0 = 68, 37, 31.2
sx = lambda v: x0 + xw * v / 0.35
box(x0, y0, xw, 2.8, "white", ec=LINE, lw=0.8, r=0.3)
ax.add_patch(Rectangle((sx(0), y0), sx(floor) - sx(0), 2.8, fc=ORANGE, ec="none", zorder=2))
ax.add_patch(Rectangle((sx(floor), y0), sx(up0) - sx(floor), 2.8, fc=ORANGE_L, ec="none", zorder=2))
ax.add_patch(Rectangle((sx(up0), y0), sx(ceil) - sx(up0), 2.8, fc="white", ec=ORANGE, lw=0.8, hatch="////", zorder=2))
for v, lab, sub in [(floor, pct(floor), "identified"), (up0, "≈%.0f%%" % (100 * up0), "if no unreported\nextensions"), (ceil, "≤%.0f%%" % (100 * ceil), "at most")]:
    ax.plot([sx(v)] * 2, [y0 - 0.2, y0 + 3.0], color=INK, lw=0.9, zorder=3)
    t(sx(v), y0 - 1.4, lab, 9, weight="bold", ha="center", va="top")
    t(sx(v), y0 - 3.6, sub, 7.2, MUTED, ha="center", va="top")

# 3b. amendment forecast
t(68, 21.2, "Forecast of amendment within 24 months (AUC)", 9.2, weight="bold")
ya = 16.6; ax_ = lambda v: 70 + (v - 0.70) / 0.18 * 33
ax.plot([ax_(auc0), ax_(auc1)], [ya, ya], color=ORANGE, lw=2.4, zorder=3)
ax.plot([ax_(auc0)], [ya], "o", ms=9, color=BLUE, mec="white", mew=1.2, zorder=4)
ax.plot([ax_(auc1)], [ya], "o", ms=9, color=ORANGE, mec="white", mew=1.2, zorder=4)
t(ax_(auc0), ya + 2.2, f"{auc0:.3f}", 9.5, BLUE, weight="bold", ha="center"); t(ax_(auc0), ya - 2.3, "at publication", 7.4, MUTED, ha="center")
t(ax_(auc1), ya + 2.2, f"{auc1:.3f}", 9.5, ORANGE, weight="bold", ha="center"); t(ax_(auc1), ya - 2.3, "revised duration", 7.4, MUTED, ha="center")
t(ax_(auc1) + 3.0, ya, "leakage that a\ntime split misses", 7.6, ORANGE, va="center")

# 3c. skill score vs error
t(68, 9.4, "Higher skill score, same error", 9.2, weight="bold")
t(68, 6.2, "Commonwealth vs state records", 7.8, MUTED)
t(68, 3.9, f"DI {di_c:.2f} vs {di_s:.2f}", 9, INK, weight="bold")
t(85.5, 3.9, f"residual error {rs_c:.2f} vs {rs_s:.2f}", 9, INK, weight="bold")
t(85.5, 6.2, "report error with any skill score", 7.8, MUTED)

fig.savefig(os.path.join(OUT, "graphical_abstract.png"), dpi=200)
fig.savefig(os.path.join(OUT, "graphical_abstract.pdf"))
print("wrote graphical_abstract.png and .pdf | floor %.3f, q0 %.3f, ceiling %.3f, AUC %.3f -> %.3f, DI %.3f/%.3f, RSD %.3f/%.3f"
      % (floor, up0, ceil, auc0, auc1, di_c, di_s, rs_c, rs_s))
