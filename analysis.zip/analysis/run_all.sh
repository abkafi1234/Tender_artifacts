#!/bin/bash
# Full pipeline, from the repository root, with tender_export.csv in the root.
set -e
PY=analysis/.venv/bin/python
mkdir -p analysis/cache analysis/run_log
run () { $PY analysis/$1.py > analysis/$1_output.txt; }
run 01_end_date_revision
$PY analysis/02_build_frames.py
for s in 03_supplementary_models 04_term_by_amendment_status 06_value_target_main 08_group_comparisons \
         09_amendment_target 10_robustness 11_descriptives 14_robust_error 07_shapley; do run $s; done
for s in 15_training_reference 16_hindsight_tiers 17_duration_equal_window 18_simple_baselines \
         19_subsample_seeds 20_implementation_table; do run $s; done
run 05_make_supp_tables; $PY analysis/12_figures.py; run 21_revision_figures; run 22_supplement_tables
$PY analysis/24_graphical_abstract.py analysis/figures
# 23 checks the numbers in the article text; it needs the manuscript source:
# $PY analysis/23_check_manuscript_numbers.py path/to/manuscript.tex
