"""LaTeX fragments for every numeric table of the Supplementary Materials, written from the result tables.

Run from the project root, after scripts 01 to 21 (script 05 writes nine further fragments to the same folder):
    analysis/.venv/bin/python analysis/22_supplement_tables.py
Output: analysis/supplement_tables/*.tex, one fragment per table, \\input by the supplement.
Nothing in these tables is typed by hand: every number is read from analysis/results/.
"""
import os
import numpy as np, pandas as pd

R = "analysis/results/"
OUT = "analysis/supplement_tables/"; os.makedirs(OUT, exist_ok=True)
rd = lambda f, **k: pd.read_csv(R + f, **k)
pc = lambda x, d=1: "--" if pd.isna(x) else f"{(round(100*x, d) or 0.0):.{d}f}\\%"  # no negative zero
com = lambda x: f"{int(round(x)):,}".replace(",", "{,}")
f3 = lambda x: "--" if pd.isna(x) else f"{x:.3f}"
f4 = lambda x: "--" if pd.isna(x) else f"{x:.4f}"
sg = lambda x, d=3: "--" if pd.isna(x) else f"{x:+.{d}f}"
pv = lambda p: "$<$0.0001" if p < 0.0001 else f"{p:.4f}"
NAMES = {"cal": "Calendar timing", "prod": "Product category", "agency": "Buying agency", "proc": "Award procedure",
         "supp": "Supplier identity", "text": "Free text", "term": "Contract term", "hist": "Amendment history"}
TIMING = {"term": "At publication, revisable", "hist": "Post-award"}


def emit(name, caption, label, colspec, header, rows, note=None, size=r"\small", pre=None):
    L = [r"\begin{table}[H]", f"\\caption{{{caption}}}", f"\\label{{{label}}}", size, r"\setlength{\tabcolsep}{3.4pt}",
         f"\\begin{{tabular}}{{{colspec}}}", r"\toprule"]
    if pre: L += pre
    L += [" & ".join(f"\\textbf{{{h}}}" if h else "" for h in header) + r" \\", r"\midrule"]
    L += [r if isinstance(r, str) else " & ".join(r) + r" \\" for r in rows]
    L += [r"\bottomrule", r"\end{tabular}"]
    if note: L.append(r"\par\vspace{2pt}\noindent{\footnotesize " + note + r"\par}")
    L.append(r"\end{table}")
    open(OUT + name + ".tex", "w", encoding="utf-8").write("\n".join(L) + "\n"); print("wrote", name)


# ============================================================ S2 and S3: data
D1 = rd("D1_sample.csv")
emit("tab_sample", "Derivation of the contract-level sample from the notices. The export is a table of notices; each "
     "Commonwealth amendment is published as a notice of its own. The analysis keeps one row per contract and attaches the "
     "amendment history to it.", "tab:sample", "p{10.4cm}r", ["Step", "Records"],
     [[(s[0].upper() + s[1:]).replace("A$", "A\\$"), com(n)] for s, n in zip(D1.step, D1.records)])

N2 = rd("D2_notices_by_year.csv")
emit("tab_notices", "Commonwealth notices and contracts by publication year. The share of notices that are amendment notices "
     "and the share of contracts later amended are different quantities: the first has no censoring, the second falls "
     "sharply for the most recent cohort, which has had under a year in which to be amended.", "tab:notices", "lrrrrr",
     ["Year", "Notices", "Amend.\\ notices", "Contracts", "Later amended", "Within 24 m"],
     [[str(int(r.yr)), com(r.notices), pc(r.share_amendment_notices), com(r.contracts), pc(r.later_amended), pc(r.amended_within_24m)]
      for r in N2.itertuples()])

D3 = rd("D3_amendment_recording.csv")
emit("tab_recording", "Amendment recording by jurisdiction, contracts first published 2010--2025. Only the Commonwealth "
     "publishes amendment notices. A rate of zero is a structural zero of the publishing system, not evidence that contracts "
     "are never amended.", "tab:recording", "lrrr", ["Jurisdiction", "Contracts", "Recorded as amended", "Rate"],
     [[{"FED": "Commonwealth"}.get(r.publisher_gov_type, r.publisher_gov_type), com(r.contracts), com(r.recorded_as_amended), pc(r.rate, 2)] for r in D3.itertuples()])

# ============================================================ S2: unit of analysis
A, B = rd("A_contract_frame.csv"), rd("B_notice_frame.csv")
rows = []
for a, b in zip(A.itertuples(), B.itertuples()):
    rows.append([str(int(a.origin)), pc(b.amend_share), pc(b.in_train), f4(b.six), f4(a.six), pc(b.share_flag_and_term), pc(a.ceiling), pc(a.floor)])
emit("tab_frames", "The same records under two units of analysis, fully observed origins. Reading each notice as a contract "
     "puts some contracts in both the training window and the evaluation year, and leads to a classification of duration as "
     "post-award. The hindsight share obtained in the notice frame is close to the contract-frame ceiling and several times "
     "the floor.", "tab:frames", "lrrrrrrr",
     ["Origin", "Amend.", "In train.", "DI six (N)", "DI six (C)", "Share (N)", "Ceiling (C)", "Floor (C)"], rows,
     note="(N) notice frame; (C) contract frame. Amend.: share of evaluation rows that are amendment notices. In train.: share "
          "of evaluation notices whose contract also appears in the five-year training window, counted before subsampling. "
          "DI six: the six descriptive blocks. Share (N): hindsight share in the notice frame with the amendment indicator and "
          "the contract term withheld.")

# ============================================================ Shapley, value target
S2 = rd("S2_shapley_value.csv").sort_values("rank")
emit("tab_shapley_value", "Exact Shapley partition of Disclosure Informativeness across the eight disclosure blocks on the "
     "contract-value target at the 2023 origin, enumerating all 256 coalitions. Values sum to the full-model DI ($%.4f$) by the "
     "efficiency property, verified numerically." % S2.shapley.sum(), "tab:shapley_value", "llrrrr",
     ["Block", "Timing", "Shapley", "Share", "95\\% CI", "Holm $p$"],
     [[NAMES[r.block], TIMING.get(r.block, "At publication"), f4(r.shapley), pc(r.share), f"[{r.lo:.3f}, {r.hi:.3f}]", f4(r.holm_p)]
      for r in S2.itertuples()],
     note="Confidence intervals from the cluster bootstrap over agencies.")

# ============================================================ S4: value target, additional results
M1 = rd("M1_di_by_origin.csv")
emit("tab_di_value", "Disclosure Informativeness of contract value by forecast origin, all eight disclosure blocks. Total and "
     "residual standard deviations are the denominator and numerator of the ratio. The balanced panel holds the set of agencies "
     "fixed. The permuted-target check (Permuted) is DI with the target permuted and the whole pipeline rebuilt.", "tab:di_value", "lrrrrrrr",
     ["Origin", "$n$", "DI", "95\\% CI", "Total SD", "Resid.\\ SD", "DI, balanced", "Permuted"],
     [[str(int(r.origin)), com(r.n_eval), f4(r.all8), f"[{r.all8_lo:.3f}, {r.all8_hi:.3f}]", f3(r.total_sd), f3(r.all8_rsd),
       f4(r.di_balanced), f4(r.sentinel)] for r in M1.itertuples()])

D6 = rd("D6_revision_by_step.csv")
emit("tab_revision", "Changes between successive notices of a contract. Each row compares one notice of a contract with the "
     "next. These pooled rates are not rates of revision: a change in value is close to a condition of an amendment notice "
     "being published, and end dates on earlier notices are overwritten (Table~\\ref{tab:revyear}).", "tab:revision", "lrrrr",
     ["Step", "Steps", "End date changed", "Median change (d)", "Value changed"],
     [[r.step, com(r.steps), pc(r.end_date_changed), f"{r.median_change_days:.0f}", pc(r.value_changed)] for r in D6.itertuples()],
     note="The parent notice displays the contract's current value, so the first row understates how often the first amendment changes it.")

D7 = rd("D7_duration_by_notice_type.csv").set_index("type")
emit("tab_durtype", "Recorded duration by notice type, Commonwealth notices with a recorded duration. Parent notices of amended "
     "contracts display current dates, so their duration includes extensions.", "tab:durtype", "lrr", ["Notice", "$n$", "Median duration (days)"],
     [[t, com(D7.loc[t, "n"]), f"{D7.loc[t, 'median_days']:.0f}"] for t in
      ["Parent notice, contract never amended", "Parent notice, contract later amended", "Amendment notice"]])

S4 = rd("S4_leave_one_out.csv")
FT = {"duration": ("Contract duration", "At publication, revisable"), "has_end": ("End date present", "At publication, revisable"),
      "pub_lag": ("Lag from start to publication", "At publication, revisable"), "ever_amended": ("Ever amended", "Post-award"),
      "n_amend": ("Number of amendments", "Post-award")}
emit("tab_loo", "Leave-one-out attribution over the contract-term and amendment-history fields at the 2023 origin. Each field "
     "is removed in turn from the full model.", "tab:loo", "llrrrr", ["Field removed", "Timing", "DI without it", "Loss", "95\\% CI", "Holm $p$"],
     [[FT[r.field][0], FT[r.field][1], f4(r.di_without), f4(r.loss), f"[{r.lo:.4f}, {r.hi:.4f}]", f4(r.holm_p)]
      for r in S4.sort_values("loss", ascending=False).itertuples()])

G11 = rd("G11_overwritten_target.csv")
emit("tab_overwrite", "DI scored separately on contracts whose value is as first published and on contracts whose value has "
     "been overwritten by an amendment, Commonwealth contracts, pooled fully observed origins.", "tab:overwrite", "lp{4.6cm}rrrr",
     ["Field set", "Contracts", "$n$", "DI", "Total SD", "Resid.\\ SD"],
     [[r.field_set, r.contracts, com(r.n), f4(r.DI), f3(r.total_sd), f3(r.resid_sd)] for r in G11.itertuples()])

G2 = rd("G2_field_availability.csv").head(6)
emit("tab_availability", "The six fields with the largest difference in availability between the Commonwealth and sub-national "
     "portals. A model given more usable fields for one group can score higher for that group irrespective of how "
     "informative either record is.", "tab:availability", "lrrr", ["Field", "Commonwealth", "State / Territory", "Gap"],
     [["\\texttt{%s}" % r.field.replace("_", "\\_"), pc(r.Commonwealth), pc(r[3]), f3(r.gap)] for r in G2.itertuples()])

G7 = rd("G7_matched_completeness.csv")
emit("tab_matched", "Completeness-matched comparison of the Commonwealth (Cw.) and the states and territories (St.) among contracts "
     "with the same number of populated optional fields.", "tab:matched", "lrrrrrrr",
     ["Fields", "$n$ Cw.", "$n$ St.", "DI Cw.", "DI St.", "Diff.", "Res.\\ SD Cw.", "Res.\\ SD St."],
     [[str(int(r.fields)), com(r.n_cw), com(r.n_st), f3(r.di_cw), f3(r.di_st), sg(r.diff), f3(r.rsd_cw), f3(r.rsd_st)] for r in G7.itertuples()])

G9 = rd("G9_compliance_agencies.csv")
nag = len(rd("G9_agencies.csv"))
emit("tab_compliance", "Compliance and DI across %d agencies. Rows marked Guard show how strongly each measure depends on the "
     "dispersion of an agency's contract values; a measure that depends on it cannot be compared across agencies. Rank "
     "correlations unless stated. Shared var.: square of the estimate." % nag, "tab:compliance", "p{8.2cm}rrr", ["Association", "Estimate", "$p$", "Shared var."],
     [[r.association, sg(r.estimate), pv(r.p), pc(r.shared_var)] for r in G9.itertuples()])

G10 = rd("G10_specification_curve.csv")
emit("tab_speccurve", "Specification curve for the compliance--informativeness relationship. The dependent variable is residual "
     "dispersion, so a negative coefficient means higher compliance is associated with a more informative record. Direction gives "
     "the sign of the coefficient irrespective of its significance.",
     "tab:speccurve", "p{6.2cm}rrrl", ["Specification", "Coef.", "SE", "$p$", "Direction"],
     [[r.specification, sg(r.coef), f3(r.se), f4(r.p), r.direction] for r in G10.itertuples()])

G6 = rd("G6_dose_response.csv")
emit("tab_dose", "DI by number of optional fields populated, seven at-publication blocks, origins 2023 to 2025 pooled. If "
     "completeness produced higher DI, this series would be expected to rise steadily.", "tab:dose", "lrrrrr",
     ["Fields populated", "$n$", "DI", "95\\% CI", "Total SD", "Residual SD"],
     [[r.group.replace("5 or fewer", "$\\leq$5"), com(r.n), f4(r.DI), f"[{r.lo:.3f}, {r.hi:.3f}]", f3(r.total_sd), f3(r.resid_sd)] for r in G6.itertuples()])

# ============================================================ S5: amendment target
T1 = rd("T1_amendment_by_origin.csv")
emit("tab_di_amend", "Forecasting amendment within 24 months of first publication, Commonwealth contracts, seven at-publication "
     "blocks. The training window ends three years before the origin year, so that every training label is fully observed when "
     "the origin year begins. AUC is the primary metric; the Brier-skill form of DI is reported with its denominator $p(1-p)$.",
     "tab:di_amend", "llrrrrrrr", ["Origin", "Training", "$n$", "Base rate", "$p(1-p)$", "AUC", "DI", "Calib.", "Permuted"],
     [[str(int(r.origin)), r.training.replace("-", "--"), com(r.n), pc(r.base_rate), f3(r.p1p), "\\textbf{%.3f}" % r.auc, f4(r.DI),
       f"{r.cal_slope:.2f}", f4(r.sentinel_di)] for r in T1.itertuples()],
     note="Calib.: calibration slope. Permuted: permuted-target check, DI with the target permuted and the whole pipeline rebuilt.")

T2 = rd("T2_duration_test.csv")
rows = [[str(int(r.origin)), pc(r.base_rate), f4(r.auc_six), f4(r.auc_six_duration), "\\textbf{%+.4f}" % r.gain, f"{r.gain_permuted:+.4f}",
         f"{r.gain_same_end:+.4f}"] for r in T2.itertuples()]
rows += [r"\midrule", ["\\textbf{Mean}", "", f4(T2.auc_six.mean()), f4(T2.auc_six_duration.mean()), "\\textbf{%+.4f}" % T2.gain.mean(),
                       f"{T2.gain_permuted.mean():+.4f}", f"{T2.gain_same_end.mean():+.4f}"]]
emit("tab_term", "Contribution of contract duration to the amendment forecast. Each variant adds one column to a model built "
     "from the six descriptive blocks and reports the change in AUC. The last column scores the same models only on contracts "
     "whose end date is identical on every notice; because earlier notices are overwritten, that is %s to %s of evaluation contracts."
     % (pc(T2.share_same_end.min()), pc(T2.share_same_end.max())), "tab:term", "lrrrrrr",
     ["Origin", "Base rate", "Six blocks", "+ duration", "Gain", "Permuted", "Same end date"], rows)

S7 = rd("S7_shapley_amend.csv").sort_values("rank")
emit("tab_shapley_amend", "Exact Shapley partition on the amendment target, enumerating all 128 coalitions of the seven "
     "at-publication blocks at the 2023 origin. The amendment history is excluded by construction because it contains the target.",
     "tab:shapley_amend", "lrrrr", ["Block", "Shapley", "Share", "95\\% CI", "Holm $p$"],
     [[NAMES[r.block], f4(r.shapley), pc(r.share), f"[{r.lo:.3f}, {r.hi:.3f}]", f4(r.holm_p)] for r in S7.itertuples()])

S8 = rd("S8_cross_target.csv").sort_values("rank_value")
from scipy import stats
rho7 = stats.spearmanr(S8.rank_value, S8.rank_amend).correlation
s6 = S8[S8.block != "term"]; rho6 = stats.spearmanr(s6.share_value, s6.share_amend).correlation
pear = np.corrcoef(S8.share_value, S8.share_amend)[0, 1]
emit("tab_cross", "Cross-target agreement over the seven at-publication blocks (Spearman $%.3f$; over the six descriptive "
     "blocks $%.3f$; Pearson on shares $%.3f$). Value-target shares are those of the seven-block partition." % (rho7, rho6, pear),
     "tab:cross", "lrrrr", ["Block", "Rank (value)", "Rank (amendment)", "Share (value)", "Share (amendment)"],
     [[NAMES[r.block], str(int(r.rank_value)), str(int(r.rank_amend)), pc(r.share_value), pc(r.share_amend)] for r in S8.itertuples()])

T4 = rd("T4_strata.csv")
emit("tab_amend_regime", "DI on the amendment target by award procedure and entity type within the Commonwealth, pooled over the "
     "three most recent origins. Strata with a base rate under 2\\% are excluded, since they have almost no variance to explain.",
     "tab:amend_regime", "lp{4.4cm}rrrrr", ["Grouping", "Stratum", "$n$", "Base rate", "AUC", "DI", "95\\% CI"],
     [[r.grouping, r.stratum, com(r.n), pc(r.base_rate), f3(r.auc), f4(r.DI), f"[{r.lo:.3f}, {r.hi:.3f}]"] for r in T4.itertuples()])

S3 = rd("S3_shapley_capacity.csv").sort_values("rank_d6")
S1b = rd("S1b_coalitions_by_depth.csv"); full = S1b[S1b["size"] == S1b["size"].max()].iloc[0]
emit("tab_capacity", "Shapley shares under three learner capacities, with all 256 coalitions re-enumerated at each. Full-model "
     "DI is $%.3f$, $%.3f$ and $%.3f$ at depths six, four and three." % (full.DI_d6, full.DI_d4, full.DI_d3), "tab:capacity",
     "lrrrrrr", ["Block", "depth 6", "depth 4", "depth 3", "d6", "d4", "d3"],
     [[NAMES[r.block], pc(r.share_d6), pc(r.share_d4), pc(r.share_d3), str(int(r.rank_d6)), str(int(r.rank_d4)), str(int(r.rank_d3))]
      for r in S3.itertuples()],
     pre=[r" & \multicolumn{3}{c}{\textbf{Share of DI}} & \multicolumn{3}{c}{\textbf{Rank}} \\", r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}"])

# ============================================================ S7: analyses added in revision
N1 = rd("N1_reference_by_origin.csv"); N1T = rd("N1_reference_trend.csv")
rows = [[str(int(r.origin)), f3(r.eval_mean), f3(r.train_mean), sg(r.mean_shift), f4(r.all8_ev), f4(r.all8_train), f4(r.all8_train_cat),
         pc(r.shift_share_of_ref_mse)] for r in N1.itertuples()]
F = N1[N1.origin <= 2023]
tp = lambda ref: N1T[(N1T.reference == ref) & (N1T.series == "all8")].mk_p.iloc[0]
rows += [r"\midrule", ["Mean", "", "", "", f4(N1.all8_ev.mean()), f4(N1.all8_train.mean()), f4(N1.all8_train_cat.mean()), ""],
         ["Trend, Mann--Kendall $p$", "", "", "", f3(tp("ev")), f3(tp("train")), f3(tp("train_cat")), ""],
         ["Floor, 2015--2023", "", "", "", pc(F.floor_ev.mean()), pc(F.floor_train.mean()), pc(F.floor_train_cat.mean()), ""],
         ["Ceiling, 2015--2023", "", "", "", pc(F.ceiling_ev.mean()), pc(F.ceiling_train.mean()), pc(F.ceiling_train_cat.mean()), ""]]
emit("tab_reference", "DI of the eight-block forecast with three reference forecasts (Eq.~1 and Eq.~3 of the article). The "
     "forecasts, and therefore the residual errors, are the same in every column; only the reference changes.", "tab:reference",
     "lrrrrrrr", ["Origin", "Eval.\\ mean", "Train.\\ mean", "Shift", "DI, eval.", "DI, train.", "DI, category", "Shift share"], rows,
     note="Eval.\\ mean and Train.\\ mean: mean log value in the evaluation year and in the five-year training window. DI, eval.: "
          "evaluation-set mean as reference (the article's DI). DI, train.: training-window mean. DI, category: training mean "
          "of the contract's product category, shrunk towards the training mean ($m = 20$). Shift share: share of the "
          "training-reference mean squared error due to the shift of the mean between the two periods.", size=r"\footnotesize")

NJ = rd("N1_reference_jurisdiction.csv")
g = NJ[NJ.group.isin(["Commonwealth", "State and territory"])].set_index("group")
d = NJ[NJ.group.str.startswith("difference")].set_index("group")
rows = []
for ref, lab in [("ev", "Each group's evaluation-set mean (article)"), ("train_group", "Each group's training-window mean"),
                 ("train_pooled", "Training-window mean of all contracts"), ("train_cat", "Training mean by product category")]:
    dd = d.loc["difference (%s)" % ref]
    rows.append([lab, f3(g.loc["Commonwealth", "DI_" + ref]), f3(g.loc["State and territory", "DI_" + ref]), sg(dd["DI_" + ref]),
                 f"[{dd.lo:+.3f}, {dd.hi:+.3f}]"])
emit("tab_reference_juris", "Jurisdiction comparison of Section~4.5 (seven at-publication blocks, origins 2023 to 2025 pooled) "
     "with four reference forecasts. The residual standard deviations are %.3f for the Commonwealth and %.3f for the states and "
     "territories in every row." % (g.loc["Commonwealth", "resid_sd"], g.loc["State and territory", "resid_sd"]),
     "tab:reference_juris", "p{6.0cm}rrrr", ["Reference forecast", "DI Cw.", "DI St.", "Diff.", "95\\% CI"], rows,
     note="Intervals from the cluster bootstrap over agencies, 2,000 replicates.")

NA = rd("N1_reference_amendment.csv")
emit("tab_reference_amend", "Amendment target: Brier skill score of the seven-block forecast with three reference forecasts. "
     "BSS, eval.\\ equals the DI of Table~\\ref{tab:di_amend}.", "tab:reference_amend", "lrrrrrr",
     ["Origin", "Base rate, eval.", "Base rate, train.", "Brier", "BSS, eval.", "BSS, train.", "BSS, category"],
     [[str(int(r.origin)), pc(r.base_rate_eval), pc(r.base_rate_train), f4(r.brier), f4(r.BSS_ev), f4(r.BSS_train), f4(r.BSS_train_cat)]
      for r in NA.itertuples()] + [r"\midrule", ["Mean", "", "", "", f4(NA.BSS_ev.mean()), f4(NA.BSS_train.mean()), f4(NA.BSS_train_cat.mean())]])

N2t = rd("N2_tiers_summary.csv")
LAB = ["(i) Identified: amendment history withheld (floor), \\% of DI",
       "(ii) Amendment target: AUC gain of first-published duration",
       "(ii) Amendment target: AUC gain of the same contracts' revised duration",
       "(ii) Value target, first-published value: extra reduction in squared error from revised duration, per contract",
       "(ii) Value target, current value: extra reduction in squared error from revised duration, per contract",
       "(iii) Inferred upper bound, $q = 0$, \\% of DI",
       "(iii) Inferred upper bound, $q = 0$, every state and territory duration a revision, \\% of DI",
       "(iii) Inferred upper bound, $q$ in the anchor range, random, \\% of DI",
       "(iii) Inferred upper bound, $q$ in the anchor range, worst case, \\% of DI",
       "Ceiling: every recorded duration a revision ($q = 1$), \\% of DI"]
rows = []
for i, r in enumerate(N2t.itertuples()):
    isshare = LAB[i].endswith("of DI")
    fm = (lambda x: pc(x)) if isshare else (lambda x: f"${x:+.3f}$")
    rng = "%s to %s" % (fm(r.lo), fm(r.hi))
    asm = r.assumption.replace("2015-2021", "2015--2021").replace("q in ", "$q$ in ").replace("q = 1", "$q = 1$")
    rows.append([LAB[i], fm(r.value), rng, asm])
emit("tab_tiers", "The hindsight evidence in three tiers, separated by what each assumes.", "tab:tiers", "p{6.4cm}rp{2.6cm}p{3.6cm}",
     ["Quantity", "Value", "Range or 95\\% CI", "Assumption"], rows, size=r"\footnotesize",
     note="Tier (i) and (iii) ranges: over the nine fully observed origins (for the anchor rows, Value is the bound at the upper "
          "end of the anchor range of $q$, and the range gives the bound at its two ends). State and territory portals publish no "
          "amendment notices, so their contracts count as never amended. Tier (ii) intervals: bootstrap over evaluation contracts. The worst case is capped at each "
          "origin's ceiling.")

T2v = rd("N2_tier2_value.csv")
emit("tab_tier2_value", "Tier (ii) on the value target: mean reduction in squared error (log value) that the contract-term block "
     "produces, origins 2024 and 2025 pooled. For amended contracts whose parent notice was not overwritten, the same model is "
     "scored with the duration as first published and with the duration after the first amendment.", "tab:tier2_value",
     "p{9.6cm}rrr", ["Evaluation set", "$n$", "Mean reduction", "95\\% CI"],
     [[r[1], com(r.n), f"{r.mean_reduction:+.3f}", f"[{r.lo:+.3f}, {r.hi:+.3f}]"] for r in T2v.itertuples()],
     note="Rows 1 to 4 and the first difference use the value shown on the parent notice as the target; the last three rows use "
          "the current value (the value of the latest amendment notice), which is what the record shows once the parent is "
          "overwritten. Bootstrap over contracts, 2,000 replicates.")

QA = rd("N2_q_anchor.csv")
emit("tab_qanchor", "Anchor for $q$: Commonwealth contracts whose every amendment notice carries an amendment value of zero, by "
     "year of first publication. Such a contract would appear never amended if zero-value notices were not published.",
     "tab:qanchor", "lrrrrr", ["Year", "Contracts", "Never amended", "Only zero-value amendments", "$q$ anchor", "Zero-value notices"],
     [[str(int(r.yr)), com(r.contracts), pc(r.never), pc(r.only_zero, 2), pc(r.q_anchor, 2), pc(r.zero_share_of_amendment_notices)]
      for r in QA.itertuples()],
     note="$q$ anchor: contracts amended only by zero-value notices as a share of those plus the never-amended contracts. "
          "Zero-value notices: share of amendment notices published in the year whose amendment value is zero.")

SQ = rd("N2_sensitivity_q.csv")
SQ = SQ[SQ.q.isin([0, 0.01, 0.02, 0.03, 0.05, 0.10, 0.20, 0.50, 1.0])]
emit("tab_sensitivity_q", "Upper bound of the hindsight share against $q$, mean over the nine fully observed origins "
     "(Figure~3 of the article).", "tab:sensitivity_q", "rrrr", ["$q$", "Random", "Random, 95\\% band", "Worst case"],
     [[pc(r.q, 0), pc(r.random_expected), "%s to %s" % (pc(r.random_lo), pc(r.random_hi)), pc(r.worst_case)] for r in SQ.itertuples()],
     note="Floor %s; ceiling %s. Random: affected contracts drawn at random, 200 draws per origin. Worst case: the contracts on "
          "which the term block reduces the squared error most, capped at each origin's ceiling." % (pc(SQ.floor.iloc[0]), pc(SQ.ceiling.iloc[0])))

BL = rd("N3_balance.csv")
VN = {"log value": "Log value", "months since January 2024": "Months since January 2024", "days to first amendment": "Days to first amendment",
      "consultancy": "Consultancy flag", "description length": "Description length (characters)", "open procedure": "Open procedure",
      "end date present": "End date present", "publication lag (days)": "Publication lag (days)", "log agency employees": "Log agency employees",
      "six-block forecast": "Six-block forecast", "share in the five largest agencies": "Share in the five largest agencies"}
b12, b6 = BL[BL.horizon_days == 365].set_index("variable"), BL[BL.horizon_days == 182].set_index("variable")
rows = [[VN[v], f3(b12.loc[v, "not_overwritten_mean"]), f3(b12.loc[v, "overwritten_mean"]), f3(b12.loc[v, "smd"]),
         f3(b6.loc[v, "not_overwritten_mean"]), f3(b6.loc[v, "overwritten_mean"]), f3(b6.loc[v, "smd"])]
        for v in b12.index if v not in ("consultancy", "end date present")]
emit("tab_balance", "Amended contracts whose parent notice was not overwritten against those whose parent was, in the two "
     "equal-window cohorts of Table~6 (panel B): means and standardised mean differences (SMD).", "tab:balance", "lrrrrrr",
     ["", "Not overwr.", "Overwr.", "SMD", "Not overwr.", "Overwr.", "SMD"], rows, size=r"\footnotesize",
     pre=[r" & \multicolumn{3}{c}{\textbf{12 months, published 2024}} & \multicolumn{3}{c}{\textbf{6 months, Jan 2024 -- Jun 2025}} \\",
          r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}"],
     note="The consultancy flag and the presence of an end date are constant in both groups and are omitted. Six-block forecast: "
          "the predicted probability of amendment from the six descriptive blocks, a summary of the observable characteristics.")

V4 = rd("N4_value_summary.csv")
rows = []
for r in V4.itertuples():
    if "floor" in r.model or "ceiling" in r.model:
        continue
    p3 = lambda p: "$<$0.001" if p < 0.0005 else f"{p:.3f}"
    rows.append([r.model, f4(r.mean_DI), f4(r.first), f4(r.last), p3(r.mk_p_DI), f3(r.mean_rsd), p3(r.mk_p_rsd)])
fl = V4.set_index("model")
rows += [r"\midrule",
         ["Floor / ceiling, ridge (2015--2023)", pc(fl.loc["Ridge: floor (mean over 2015-2023)", "mean_DI"]) + " / " +
          pc(fl.loc["Ridge: ceiling (mean over 2015-2023)", "mean_DI"]), "", "", "", "", ""],
         ["Floor / ceiling, boosted trees (2015--2023)", pc(fl.loc["Boosted trees: floor (mean over 2015-2023)", "mean_DI"]) + " / " +
          pc(fl.loc["Boosted trees: ceiling (mean over 2015-2023)", "mean_DI"]), "", "", "", "", ""]]
emit("tab_baselines_value", "Value target: simpler models beside the boosted trees, eleven origins. The lookup and the ridge "
     "regression use the same training samples as the boosted trees; the ridge regression also uses the same features.",
     "tab:baselines_value", "p{5.6cm}rrrrrr", ["Model", "Mean DI", "2015", "2025", "Trend $p$", "Mean RSD", "RSD trend $p$"], rows,
     note="Group-mean lookup: training mean of log value by product category and agency, shrunk towards the category mean and then "
          "the overall mean ($m = 20$). Ridge: $\\alpha = 1$; skewed numeric fields enter as signed $\\log(1+|x|)$, missing values "
          "are imputed with the training median plus an indicator, and all features are standardised on training rows. RSD: "
          "residual standard deviation. Trend: Mann--Kendall.")

A4 = rd("N4_amend_by_origin.csv")
rows = [[str(int(r.origin)), f3(r.logit_auc_six), f3(r.logit_auc_six_duration), f"{r.logit_gain:+.3f}", f3(r.logit_auc_seven),
         f3(r.xgb_auc_six), f3(r.xgb_auc_six_duration), f"{r.xgb_gain:+.3f}", f3(r.xgb_auc_seven)] for r in A4.itertuples()]
m = A4.mean()
rows += [r"\midrule", ["Mean", f3(m.logit_auc_six), f3(m.logit_auc_six_duration), f"{m.logit_gain:+.3f}", f3(m.logit_auc_seven),
                       f3(m.xgb_auc_six), f3(m.xgb_auc_six_duration), f"{m.xgb_gain:+.3f}", f3(m.xgb_auc_seven)]]
emit("tab_baselines_amend", "Amendment target: AUC of logistic regression (L2, $C = 1$, same features and preprocessing as the "
     "ridge regression) beside the boosted trees.", "tab:baselines_amend", "lrrrrrrrr",
     ["Origin", "Six", "+ dur.", "Gain", "Seven", "Six", "+ dur.", "Gain", "Seven"], rows, size=r"\footnotesize",
     pre=[r" & \multicolumn{4}{c}{\textbf{Logistic regression}} & \multicolumn{4}{c}{\textbf{Boosted trees}} \\",
          r"\cmidrule(lr){2-5}\cmidrule(lr){6-9}"])

DT = rd("N4_duration_test.csv")
emit("tab_baselines_duration", "The duration test of Table~6 (panel A) with logistic regression.", "tab:baselines_duration",
     "p{6.4cm}rrrrr", ["Amended contracts in evaluation set", "$n$", "Six", "+ dur.", "Gain", "95\\% CI"],
     [[r[1].replace("Parent", "Parent").replace(";", ";"), com(r.n_amended), f3(r.auc_six), f3(r.auc_six_duration), "\\textbf{%+.3f}" % r.gain,
       f"[{r.lo:+.3f}, {r.hi:+.3f}]"] for r in DT.itertuples()])

S5 = rd("N5_seeds_summary.csv")
rows = [[str(int(r.seed)) + (" (article)" if r.seed == 0 else ""), f4(r.mean_all8), pc(r.floor_mean), pc(r.ceiling_mean), f4(r.mk_p_all8),
         f3(r.mk_p_rsd_all8), f"{r.last3_minus_first3:+.3f}"] for r in S5.itertuples()]
rows += [r"\midrule", ["Range", "%s to %s" % (f4(S5.mean_all8.min()), f4(S5.mean_all8.max())), "%s to %s" % (pc(S5.floor_mean.min()), pc(S5.floor_mean.max())),
                       "%s to %s" % (pc(S5.ceiling_mean.min()), pc(S5.ceiling_mean.max())), "%s to %s" % (f4(S5.mk_p_all8.min()), f4(S5.mk_p_all8.max())),
                       "%s to %s" % (f3(S5.mk_p_rsd_all8.min()), f3(S5.mk_p_rsd_all8.max())), "%+.3f to %+.3f" % (S5.last3_minus_first3.min(), S5.last3_minus_first3.max())]]
emit("tab_seeds", "Sensitivity to the training subsample and the learner seed, value target. Seed $s$ draws the 100{,}000-row "
     "subsample with seed $20261005 + \\text{origin} + 1000s$ and fits the learner with seed $20261005 + s$; seed 0 is the specification reported in the article.",
     "tab:seeds", "lrrrrrr", ["Seed", "Mean DI", "Floor", "Ceiling", "DI trend $p$", "RSD trend $p$", "Last 3 $-$ first 3"], rows,
     size=r"\footnotesize", note="Floor and ceiling: mean over 2015--2023. Trend: Mann--Kendall over the eleven origins.")

NS = rd("N5_no_subsample.csv")
emit("tab_nosubsample", "Training on the full five-year window without subsampling, against the 100{,}000-row subsample of the "
     "article, at three origins.", "tab:nosubsample", "lrrrrrrrr",
     ["Origin", "Training rows", "DI", "DI, sub.", "Floor", "Floor, sub.", "Ceiling", "Ceiling, sub.", "RSD"],
     [[str(int(r.origin)), com(r.n_train), f4(r.all8), f4(r.all8_sub), pc(r.floor), pc(r.floor_sub), pc(r.ceiling), pc(r.ceiling_sub), f3(r.all8_rsd)]
      for r in NS.itertuples()], size=r"\footnotesize")

impl = open(R + "N6_implementation.tex", encoding="utf-8").read()
open(OUT + "tab_implementation.tex", "w", encoding="utf-8").write(
    "\\begin{table}[H]\n\\caption{Implementation details, generated from the code (script 20).}\n\\label{tab:implementation}\n"
    "\\footnotesize\n" + impl + "\\end{table}\n")
print("wrote tab_implementation")
