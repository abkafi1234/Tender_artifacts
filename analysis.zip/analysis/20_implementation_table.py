"""A6. Implementation table, generated from the code (round 1 revision, comments E4, R2.5).

Run from the project root:
    analysis/.venv/bin/python analysis/20_implementation_table.py > analysis/20_implementation_table_output.txt
Values are read from lib.py and the installed packages, so the table cannot drift from the code.
Output: analysis/results/N6_implementation.csv and N6_implementation.tex (a LaTeX table fragment)
"""
import inspect, platform, re, sys
import numpy as np, pandas as pd, scipy, sklearn, xgboost
import lib
from lib import *

src = inspect.getsource(lib.encode)
m_smooth = re.search(r"m = y\.mean\(\), ([0-9.]+)", src).group(1)
kfold = re.search(r"KFold\((\d+)", src).group(1)
tfa = dict(kv.split("=") for kv in re.search(r"TfidfVectorizer\(([^)]*)\)", src).group(1).replace(" ", "").split(","))
tf = "minimum document frequency %s, at most %s terms, sublinear term frequency" % (tfa["min_df"], format(int(tfa["max_features"]), ","))
ridge_alpha = re.search(r"Ridge\(alpha=([0-9.]+)", src).group(1)
hp = ", ".join("%s = %s" % (k, v) for k, v in HP.items() if k not in ("n_jobs", "random_state"))

rows = [
    ("Software", "Python %s; numpy %s; pandas %s; scipy %s; scikit-learn %s; xgboost %s" %
     (platform.python_version(), np.__version__, pd.__version__, scipy.__version__, sklearn.__version__, xgboost.__version__)),
    ("Learner", "Gradient-boosted trees (XGBRegressor for the value target, XGBClassifier for the amendment target); " + hp),
    ("Lower capacities (Shapley partition)", "max_depth 4 and 3; shallow learner max_depth 2; other settings unchanged"),
    ("Hyperparameter tuning", "None; the settings are fixed in advance and used at every origin, for every field set and both targets"),
    ("Training window", "Value target: five years before the origin (Y-5 to Y-1). Amendment target: Y-7 to Y-3, so that every 24-month label is observed at the origin"),
    ("Training sample", "%s rows drawn at random without replacement when the window is larger (random_state = %d + origin)" % (format(NTRAIN, ","), SEED)),
    ("Evaluation set", "All contracts first published in the origin year"),
    ("Categorical fields", "Smoothed target mean (shrinkage m = %s towards the training mean) and log(1 + count); fitted out of fold (%s folds) on training rows, on all training rows for evaluation rows; unseen levels get the training mean and a count of zero" % (m_smooth, kfold)),
    ("Missing values", "Categorical: a separate missing-value level. Numeric (duration, publication lag, agency size): left missing, handled by the learner's default split direction"),
    ("Free text", "Title and description, lower case; TF-IDF (%s) and a ridge regression (alpha = %s) whose out-of-fold prediction enters as one feature" % (tf.replace("_", " "), ridge_alpha)),
    ("Target", "Value: natural log of the current contract value; values of A$1 or less excluded. Amendment: an amendment notice within 730 days of first publication"),
    ("Measure", "DI = 1 minus the ratio of SSE to the sum of squared deviations from the evaluation-set mean (Eq. 1); also computed with the training-window mean as the reference"),
    ("Seeds", "Global seed %d; fold assignment, subsample and learner seeded from it; 10 further seeds in the sensitivity analysis" % SEED),
    ("Inference", "Unless stated otherwise, cluster bootstrap over buying agencies, %s replicates (Table 6 and the tier (ii) estimates: bootstrap over evaluation contracts); Mann--Kendall trend test with Sen's slope; Holm correction within families" % format(NBOOT, ",")),
    ("Origins", "Value target %d to %d (amendment history fully observed %d to %d); amendment target %d to %d" % (ORIGINS[0], ORIGINS[-1], FULL[0], FULL[-1], AM_ORIGINS[0], AM_ORIGINS[-1])),
    ("Hardware and time", "Apple silicon, 10 cores; run times in run_log/status.tsv and run_log/status_new.tsv"),
]
T = pd.DataFrame(rows, columns=["Item", "Setting"]); T.to_csv(RES + "N6_implementation.csv", index=False)
print(T.to_string(index=False))

esc = lambda s: s.replace("&", r"\&").replace("%", r"\%").replace("_", r"\_").replace("A$", r"A\$")
L = [r"\begin{tabular}{@{}p{3.6cm}p{11.4cm}@{}}", r"\toprule", r"\textbf{Item} & \textbf{Setting} \\", r"\midrule"]
L += ["%s & %s \\\\" % (esc(a), esc(b)) for a, b in rows]
L += [r"\bottomrule", r"\end{tabular}"]
open(RES + "N6_implementation.tex", "w", encoding="utf-8").write("\n".join(L) + "\n")
print("\nwrote", RES + "N6_implementation.tex")
